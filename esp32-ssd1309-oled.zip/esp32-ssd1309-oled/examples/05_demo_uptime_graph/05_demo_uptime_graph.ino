// Demo: uptime, animated progress bar and a scrolling graph (fake sensor wave).

#include <Wire.h>
#include <U8g2lib.h>
#include <math.h>

U8G2_SSD1309_128X64_NONAME0_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);

const int GRAPH_W = 128;
uint8_t graph[GRAPH_W];   // values 0..19 (graph height)
int gpos = 0;

void setup() {
  Wire.begin(21, 22);
  u8g2.setI2CAddress(0x3C * 2);
  u8g2.begin();
  u8g2.setContrast(150);
  for (int i = 0; i < GRAPH_W; i++) graph[i] = 0;
}

void loop() {
  unsigned long s = millis() / 1000;
  char line[24];
  snprintf(line, sizeof(line), "Up %02lu:%02lu:%02lu", s / 3600, (s / 60) % 60, s % 60);

  // fake sensor value: sine wave mapped to 0..19
  float t = millis() / 1000.0;
  graph[gpos] = (uint8_t)(9.5 + 9.0 * sin(t));
  gpos = (gpos + 1) % GRAPH_W;

  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_6x10_tr);
  u8g2.drawStr(0, 10, line);

  // progress bar cycling every 10 s
  int bar = (millis() % 10000) * 126 / 10000;
  u8g2.drawFrame(0, 16, 128, 8);
  u8g2.drawBox(1, 17, bar, 6);

  // scrolling graph in the bottom 20 px
  for (int x = 0; x < GRAPH_W; x++) {
    int idx = (gpos + x) % GRAPH_W;
    u8g2.drawPixel(x, 63 - graph[idx]);
  }
  u8g2.drawHLine(0, 63, 128);

  u8g2.sendBuffer();
  delay(50);
}
