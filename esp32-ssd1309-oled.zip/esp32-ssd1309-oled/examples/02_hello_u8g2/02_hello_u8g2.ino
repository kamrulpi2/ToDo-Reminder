// Hello World with U8g2 on the SSD1309 2.42" OLED. Known working at 0x3C.
// Wiring: GND-GND, VDD-3V3, SCL-GPIO22, SDA-GPIO21.

#include <Wire.h>
#include <U8g2lib.h>

U8G2_SSD1309_128X64_NONAME0_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);

void setup() {
  Wire.begin(21, 22);              // SDA, SCL
  u8g2.setI2CAddress(0x3C * 2);    // U8g2 wants the 8-bit address; use 0x3D * 2 if your board is 0x3D
  u8g2.begin();
  u8g2.setContrast(255);           // lower (e.g. 100) to reduce burn-in
}

void loop() {
  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_ncenB14_tr);
  u8g2.drawStr(0, 24, "Hello ESP32");
  u8g2.setFont(u8g2_font_6x10_tr);
  u8g2.drawStr(0, 50, "SSD1309 working!");
  u8g2.sendBuffer();
  delay(500);
}
