// Draws the address being tried on screen, cycling 0x3C, 0x3D, 0x1A every 3 s.
// Whichever address makes text appear on the display is the right one.

#include <Wire.h>
#include <U8g2lib.h>

U8G2_SSD1309_128X64_NONAME0_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);
byte addrs[] = {0x3C, 0x3D, 0x1A};

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);
}

void loop() {
  for (byte i = 0; i < 3; i++) {
    u8g2.setI2CAddress(addrs[i] * 2);
    u8g2.begin();
    u8g2.setContrast(255);
    u8g2.clearBuffer();
    u8g2.setFont(u8g2_font_ncenB14_tr);
    char buf[16];
    snprintf(buf, sizeof(buf), "Addr 0x%02X", addrs[i]);
    u8g2.drawStr(0, 30, buf);
    u8g2.sendBuffer();
    Serial.println(buf);
    delay(3000);
  }
}
