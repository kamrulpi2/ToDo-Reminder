// I2C scanner for ESP32. Open Serial Monitor at 115200, press EN.
// Expected with the display working: "Found device at 0x3C" (or 0x3D).
// "Nothing found" or only 0x1A -> bridge D1/D2 on the display (see docs/TROUBLESHOOTING.md).

#include <Wire.h>

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22); // SDA = GPIO21, SCL = GPIO22
  delay(1000);
  Serial.println("Scanning...");

  int found = 0;
  for (byte a = 1; a < 127; a++) {
    Wire.beginTransmission(a);
    if (Wire.endTransmission() == 0) {
      Serial.printf("Found device at 0x%02X\n", a);
      found++;
    }
  }

  if (!found) Serial.println("Nothing found: check D1/D2 bridge, wiring, power");
  else Serial.println("Done");
}

void loop() {}
