// Host simulation of the BeeClock sketch: compiles the real sketch files against PC stubs,
// runs the real displayTask on a virtual clock and dumps OLED frames.
#include "Arduino.h"
#include "../../projects/bee_clock_todo/bee_clock_todo.ino"

uint32_t g_ms = 0; long long g_base = 0;
SerialClass Serial; EspClass ESP; TwoWire Wire; WiFiClass WiFi; MDNSResponder MDNS; LittleFSClass LittleFS;
sntp_sync_status_t g_sntp = SNTP_SYNC_STATUS_RESET;
std::function<void(const uint8_t*)> g_frameHook;
std::map<std::string, std::string> g_args; std::string g_resp, g_uri; int g_code = 0;
int g_httpCode = 200; std::string g_httpBody = "null", g_httpLastPut, g_httpLastUrl;

struct StopSim {};
std::function<void(uint32_t)> g_step;
static std::vector<void (*)(void*)> g_tasks;
void vTaskDelay(TickType_t t) { g_ms += t; if (g_step) g_step(g_ms); }
TickType_t xTaskGetTickCount() { return g_ms; }
void vTaskDelayUntil(TickType_t* prev, TickType_t inc) { *prev += inc; if (*prev > g_ms) g_ms = *prev; if (g_step) g_step(g_ms); }
int xTaskCreatePinnedToCore(void (*fn)(void*), const char* n, uint32_t, void*, int, TaskHandle_t*, int) { printf("[rtos] task '%s'\n", n); g_tasks.push_back(fn); return 1; }

static int fails = 0;
#define CHECK(c, msg) do { if (!(c)) { printf("FAIL: %s\n", msg); fails++; } else printf("ok:   %s\n", msg); } while (0)

static Task mk(const char* title, const char* date, const char* tm_, int prio, int rep, bool done = false, const char* doneOn = "") {
  Task t; t.id = nextId++; t.title = title; t.date = date; t.time = tm_; t.prio = prio; t.rep = rep; t.done = done; t.doneOn = doneOn; return t;
}

int main(int argc, char** argv) {
  const char* out = argc > 1 ? argv[1] : "frames.bin";
  g_base = 1791944990LL;                      // 2026-10-14 02:29:50 UTC = 08:29:50 in Dhaka (set below by test)
  system("rm -rf /tmp/beeclock_fs && mkdir -p /tmp/beeclock_fs");

  // ---------------- boot (the real setup(), tasks are only recorded) ----------------
  setup();
  CHECK(apSsid == "BeeClock-A1B2" || apSsid.length() > 9, "hotspot name built from MAC");
  CHECK(cfg.fbUrl == FB_DEFAULT_URL, "Firebase URL pre-filled with your database");
  CHECK(g_tasks.size() == 6, "6 RTOS tasks created (display, alarm, button, net, sync, housekeeping)");
  { char tz[24]; applyTimezone(tz); CHECK(String(tz) == "UTC-6:00", "time zone Dhaka -> POSIX UTC-6:00"); }

  // ---------------- offline time restore ----------------
  g_base = 0; g_ms = 0;
  prefs.putULong("lt", 1791944000UL);
  restoreSavedTime();
  CHECK(timeValid() && timeApprox, "no WiFi: time restored from flash and marked approximate");
  { tm t; nowLocal(t); CHECK(t.tm_hour == 8 && t.tm_min == 13, "restored time shows 08:13 local (Dhaka)"); }
  g_base = 1791944990LL;                      // pretend the clock keeps running
  tasks.clear(); nextId = 1;

  // ---------------- tasks for the screen ----------------
  tasks.push_back(mk("Buy milk", "", "08:45", 1, 0));
  tasks.push_back(mk("Fix ESP32 bee code", "", "10:30", 2, 0));
  tasks.push_back(mk("Call mom", "", "07:30", 1, 0));
  tasks.push_back(mk("Send invoice", "", "09:00", 1, 0, true, "2026-10-14"));
  tasks.push_back(mk("Water plants", "", "18:00", 1, 1));
  tasks.push_back(mk("Pay internet bill", "2026-10-16", "", 0, 0));
  tasks.push_back(mk("Read 10 pages", "", "", 1, 0));
  tasks.push_back(mk("Gym", "2026-10-14", "20:00", 1, 2));

  // ---------------- API handlers ----------------
  g_args["plain"] = "{\"title\":\"API task\",\"date\":\"2026-10-14\",\"time\":\"23:59\",\"prio\":2,\"rep\":0}";
  apiTaskAdd();
  CHECK(g_resp.find("\"ok\":true") != std::string::npos && tasks.size() == 9, "API add task");
  g_args["plain"] = "{\"title\":\"x\",\"time\":\"99:99\"}";
  apiTaskAdd(); CHECK(g_code == 400, "API rejects bad time");
  g_args["plain"] = "{\"id\":9}"; apiTaskToggle();
  CHECK(tasks.back().done, "API toggle done");
  g_args["plain"] = "{\"id\":9}"; apiTaskDelete();
  CHECK(tasks.size() == 8, "API delete");
  apiState();
  { JsonDocument d; deserializeJson(d, g_resp); CHECK(d["tasks"].size() == 8 && d["valid"] == true, "API state JSON parses, 8 tasks"); }
  g_args["plain"] = "{\"epoch\":1791950000,\"tz\":360,\"ntp\":false}"; apiTime();
  CHECK(!timeApprox && !cfg.ntp, "phone sets time -> no longer approximate");
  g_base = 1791944990LL - g_ms / 1000;        // restore the scenario time
  cfg.ntp = true;

  // ---------------- JSON roundtrip + Firebase sync logic ----------------
  { String js; { Guard g; tasksToJson(tasks, js); } std::vector<Task> back; CHECK(tasksFromJson(js, back) && back.size() == tasks.size(), "tasks JSON roundtrip"); }
  fbPushedGen = fbGen;                        // booted, nothing pending
  g_httpCode = 200;
  g_httpBody = "{\"t5\":{\"id\":5,\"title\":\"From cloud\",\"date\":\"\",\"time\":\"11:11\",\"prio\":1,\"rep\":0,\"done\":false}}";
  CHECK(fbPull() && tasks.size() == 1 && tasks[0].title == "From cloud", "Firebase pull replaces local list when nothing is pending");
  tasks.clear(); nextId = 1;
  g_httpBody = "null"; fbSeeded = false; tasks.push_back(mk("Local only", "", "", 1, 0));
  fbPull(); CHECK(fbGen != fbPushedGen, "empty cloud + local tasks -> uploads local (seed)");
  fbPush(); CHECK(g_httpLastPut.find("Local only") != std::string::npos && g_httpLastUrl.find("test1-99d84") != std::string::npos, "Firebase push goes to your database URL");
  tasks.clear(); nextId = 1;
  tasks.push_back(mk("Buy milk", "", "08:45", 1, 0));
  tasks.push_back(mk("Fix ESP32 bee code", "", "10:30", 2, 0));
  tasks.push_back(mk("Call mom", "", "07:30", 1, 0));
  tasks.push_back(mk("Send invoice", "", "09:00", 1, 0, true, "2026-10-14"));
  tasks.push_back(mk("Water plants", "", "18:00", 1, 1));
  tasks.push_back(mk("Pay internet bill", "2026-10-16", "", 0, 0));
  tasks.push_back(mk("Read 10 pages", "", "", 1, 0));
  tasks.push_back(mk("Gym", "2026-10-14", "20:00", 1, 2));
  tasks.push_back(mk("A very long task name that does not fit", "", "12:00", 2, 0));

  // ---------------- run the real displayTask on a virtual clock ----------------
  FILE* fo = fopen(out, "wb");
  uint32_t nextCap = 0;
  g_frameHook = [&](const uint8_t* fb) {
    if (g_ms >= nextCap) { nextCap = g_ms + 250; fwrite(&g_ms, 4, 1, fo); fwrite(fb, 1, 8192, fo); }
  };
  g_ms = 0; g_base = 1791944990LL;
  netState = NET_CONNECTING; timeApprox = true;
  bool alarmChecked = false;
  g_step = [&](uint32_t ms) {
    if (ms >= 6000 && netState == NET_CONNECTING) netState = NET_PORTAL;               // hotspot (no WiFi)
    if (ms >= 45000 && netState == NET_PORTAL) { netState = NET_ONLINE; ipInfoUntil = ms + 9000; { Guard g; ipInfo = "192.168.0.57"; } timeApprox = false; }
    if (ms >= 70000 && !alertActive && !alarmChecked) { alarmChecked = true; alarmTrigger(3, "Call mom"); }
    if (ms >= 75000 && alertActive) alertActive = false;
    if (ms >= 80000) throw StopSim();
  };
  try { displayTask(nullptr); } catch (StopSim&) {}
  fclose(fo);

  // alarm engine: task due at 08:45 should ring only when time is trusted
  g_ms = 0; g_base = 1791944990LL; alertActive = false;
  g_base = 1791946500LL - 0;                  // 08:55 Dhaka? (checked below) -> use exact minute
  { tm t; nowLocal(t); printf("[test] alarm clock now %02d:%02d\n", t.tm_hour, t.tm_min); }
  tasks.clear(); nextId = 1; tasks.push_back(mk("Ring me", "", fmtHM([]{ tm t; nowLocal(t); return t; }()).c_str(), 1, 0));
  timeApprox = true;
  { tm t; nowLocal(t); }
  checkDue(); CHECK(alertActive, "checkDue rings when the minute matches (alarmTask gates on trusted time)");
  alarmStop(); checkDue(); CHECK(!alertActive, "same minute does not ring twice");

  printf("\n%s (%d failed)\n", fails ? "SOME CHECKS FAILED" : "ALL HOST CHECKS PASSED", fails);
  return fails ? 1 : 0;
}
