#pragma once
#include "Arduino.h"
#include <fstream>
#include <sstream>
struct File {
  std::string path, mode; std::string buf; bool ok = false;
  explicit operator bool() const { return ok; }
  void print(const String& s) { buf += s.c_str(); }
  String readString() { std::ifstream f(path); std::stringstream ss; ss << f.rdbuf(); return String(ss.str().c_str()); }
  void close() { if (mode == "w") { std::ofstream f(path); f << buf; } }
};
struct LittleFSClass {
  bool begin(bool = false) { return true; }
  File open(const char* p, const char* m = "r") {
    File f; f.path = std::string("/tmp/beeclock_fs") + p; f.mode = m;
    if (std::string(m) == "r") { std::ifstream t(f.path); f.ok = t.good(); } else f.ok = true;
    return f;
  }
};
extern LittleFSClass LittleFS;
