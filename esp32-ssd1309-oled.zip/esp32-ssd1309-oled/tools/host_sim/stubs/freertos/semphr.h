#pragma once
#include "FreeRTOS.h"
typedef std::recursive_mutex* SemaphoreHandle_t;
inline SemaphoreHandle_t xSemaphoreCreateRecursiveMutex() { return new std::recursive_mutex(); }
inline int xSemaphoreTakeRecursive(SemaphoreHandle_t h, TickType_t) { h->lock(); return 1; }
inline int xSemaphoreGiveRecursive(SemaphoreHandle_t h) { h->unlock(); return 1; }
