#pragma once
#include "../Arduino.h"
typedef uint32_t TickType_t;
#define pdMS_TO_TICKS(x) ((TickType_t)(x))
#define portMAX_DELAY 0xFFFFFFFFu
typedef void* TaskHandle_t;
void vTaskDelay(TickType_t t);
TickType_t xTaskGetTickCount();
void vTaskDelayUntil(TickType_t* prev, TickType_t inc);
int xTaskCreatePinnedToCore(void (*fn)(void*), const char* name, uint32_t stack, void* arg, int prio, TaskHandle_t* h, int core);
