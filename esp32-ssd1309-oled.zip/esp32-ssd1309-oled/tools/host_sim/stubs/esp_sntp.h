#pragma once
#include "Arduino.h"
enum sntp_sync_status_t { SNTP_SYNC_STATUS_RESET, SNTP_SYNC_STATUS_COMPLETED, SNTP_SYNC_STATUS_IN_PROGRESS };
inline bool esp_sntp_enabled() { return false; }
inline void esp_sntp_stop() {}
inline bool sntp_enabled() { return false; }
inline void sntp_stop() {}
extern sntp_sync_status_t g_sntp;
inline sntp_sync_status_t sntp_get_sync_status() { return g_sntp; }
