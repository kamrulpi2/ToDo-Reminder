#pragma once
#include <string>
#include "Print.h"
// Small Arduino-compatible String on top of std::string
class String {
 public:
  std::string s;
  String() {}
  String(const char* c) { if (c) s = c; }
  String(char c) { s = std::string(1, c); }
  String(const String& o) : s(o.s) {}
  explicit String(int v) { s = std::to_string(v); }
  explicit String(unsigned v) { s = std::to_string(v); }
  explicit String(long v) { s = std::to_string(v); }
  explicit String(unsigned long v) { s = std::to_string(v); }
  explicit String(unsigned long long v) { s = std::to_string(v); }
  String& operator=(const String& o) { s = o.s; return *this; }
  String& operator=(const char* c) { s = c ? c : ""; return *this; }
  unsigned length() const { return (unsigned)s.size(); }
  const char* c_str() const { return s.c_str(); }
  char operator[](unsigned i) const { return i < s.size() ? s[i] : 0; }
  char& operator[](unsigned i) { return s[i]; }
  String& operator+=(const String& o) { s += o.s; return *this; }
  String& operator+=(const char* c) { s += c; return *this; }
  String& operator+=(char c) { s += c; return *this; }
  bool concat(const char* c, unsigned n) { s.append(c, n); return true; }
  bool concat(const char* c) { s += c; return true; }
  bool concat(char c) { s += c; return true; }
  bool concat(const String& o) { s += o.s; return true; }
  bool reserve(unsigned n) { s.reserve(n); return true; }
  void remove(unsigned idx) { if (idx < s.size()) s.erase(idx); }
  void remove(unsigned idx, unsigned cnt) { if (idx < s.size()) s.erase(idx, cnt); }
  bool startsWith(const String& p) const { return s.compare(0, p.s.size(), p.s) == 0 && s.size() >= p.s.size(); }
  bool endsWith(const String& p) const { return s.size() >= p.s.size() && s.compare(s.size() - p.s.size(), p.s.size(), p.s) == 0; }
  String substring(unsigned from) const { return from >= s.size() ? String() : String(s.substr(from).c_str()); }
  String substring(unsigned from, unsigned to) const { if (to > s.size()) to = s.size(); return from >= to ? String() : String(s.substr(from, to - from).c_str()); }
  void trim() { size_t a = s.find_first_not_of(" \t\r\n"); if (a == std::string::npos) { s.clear(); return; } size_t b = s.find_last_not_of(" \t\r\n"); s = s.substr(a, b - a + 1); }
  long toInt() const { return atol(s.c_str()); }
  bool operator==(const String& o) const { return s == o.s; }
  bool operator==(const char* c) const { return s == c; }
  bool operator!=(const String& o) const { return s != o.s; }
  bool operator!=(const char* c) const { return s != c; }
  bool operator<(const String& o) const { return s < o.s; }
  bool operator>(const String& o) const { return s > o.s; }
  explicit operator bool() const = delete;
};
inline String operator+(const String& a, const String& b) { String r(a); r += b; return r; }
inline String operator+(const String& a, const char* b) { String r(a); r += b; return r; }
inline String operator+(const char* a, const String& b) { String r(a); r += b; return r; }
inline String operator+(const String& a, char b) { String r(a); r += b; return r; }
inline size_t Print::print(const String& s) { return write(s.c_str()); }
