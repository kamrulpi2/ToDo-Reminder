#pragma once
#include <cstdint>
#define pgm_read_byte(a) (*(const unsigned char*)(a))
#define pgm_read_word(a) (*(const unsigned short*)(a))
#define pgm_read_dword(a) (*(const unsigned int*)(a))
typedef const char* PGM_P;
