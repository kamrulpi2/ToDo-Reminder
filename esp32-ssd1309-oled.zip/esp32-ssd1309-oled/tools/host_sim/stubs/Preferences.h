#pragma once
#include "Arduino.h"
struct Preferences {
  std::map<std::string, std::string> m;
  bool begin(const char*, bool = false) { return true; }
  String getString(const char* k, const String& d = "") { auto i = m.find(k); return i == m.end() ? d : String(i->second.c_str()); }
  void putString(const char* k, const String& v) { m[k] = v.c_str(); }
  int getInt(const char* k, int d = 0) { auto i = m.find(k); return i == m.end() ? d : atoi(i->second.c_str()); }
  void putInt(const char* k, int v) { m[k] = std::to_string(v); }
  bool getBool(const char* k, bool d = false) { return getInt(k, d) != 0; }
  void putBool(const char* k, bool v) { putInt(k, v); }
  uint8_t getUChar(const char* k, uint8_t d = 0) { return (uint8_t)getInt(k, d); }
  void putUChar(const char* k, uint8_t v) { putInt(k, v); }
  uint32_t getULong(const char* k, uint32_t d = 0) { auto i = m.find(k); return i == m.end() ? d : (uint32_t)strtoul(i->second.c_str(), 0, 10); }
  void putULong(const char* k, uint32_t v) { m[k] = std::to_string(v); }
};
