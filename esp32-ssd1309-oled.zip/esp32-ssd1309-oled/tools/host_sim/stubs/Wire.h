#pragma once
#include "Arduino.h"
struct TwoWire {
  bool begin(int = -1, int = -1, uint32_t = 0) { return true; }
  void setClock(uint32_t) {}
  void beginTransmission(int) {}
  int endTransmission(bool = true) { return 0; }
};
extern TwoWire Wire;
