#pragma once
#include "Arduino.h"
#include "Wire.h"
#include <Adafruit_GFX.h>
#define SSD1306_WHITE 1
#define SSD1306_BLACK 0
#define SSD1306_SWITCHCAPVCC 2
#define SSD1306_SETCONTRAST 0x81
extern std::function<void(const uint8_t*)> g_frameHook;
class Adafruit_SSD1306 : public Adafruit_GFX {
 public:
  uint8_t fb[128 * 64];
  Adafruit_SSD1306(uint8_t w, uint8_t h, TwoWire*, int8_t) : Adafruit_GFX(w, h) { memset(fb, 0, sizeof fb); }
  bool begin(uint8_t = 2, uint8_t = 0, bool = true, bool = true) { return true; }
  void drawPixel(int16_t x, int16_t y, uint16_t c) override { if (x >= 0 && x < 128 && y >= 0 && y < 64) fb[y * 128 + x] = c ? 1 : 0; }
  void clearDisplay() { memset(fb, 0, sizeof fb); }
  void display() { if (g_frameHook) g_frameHook(fb); }
  void ssd1306_command(uint8_t) {}
};
