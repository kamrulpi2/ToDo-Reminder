#pragma once
#include "WiFi.h"
struct DNSServer {
  bool start(uint16_t, const String&, const IPAddress&) { return true; }
  void stop() {}
  void processNextRequest() {}
};
