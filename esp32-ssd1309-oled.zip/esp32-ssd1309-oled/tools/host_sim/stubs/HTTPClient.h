#pragma once
#include "WiFiClientSecure.h"
extern int g_httpCode; extern std::string g_httpBody, g_httpLastPut, g_httpLastUrl;
struct HTTPClient {
  bool begin(WiFiClientSecure&, const String& u) { g_httpLastUrl = u.c_str(); return true; }
  void setConnectTimeout(int) {}
  void setTimeout(int) {}
  void addHeader(const char*, const char*) {}
  int PUT(const String& b) { g_httpLastPut = b.c_str(); return g_httpCode; }
  int GET() { return g_httpCode; }
  String getString() { return String(g_httpBody.c_str()); }
  void end() {}
};
