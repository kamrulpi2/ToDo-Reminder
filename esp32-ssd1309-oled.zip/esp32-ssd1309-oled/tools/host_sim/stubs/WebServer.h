#pragma once
#include "WiFi.h"
enum HTTPMethod { HTTP_GET, HTTP_POST };
extern std::map<std::string, std::string> g_args;
extern std::string g_resp, g_uri;
extern int g_code;
struct WebServer {
  WebServer(int) {}
  typedef std::function<void(void)> THandlerFunction;
  void on(const char*, HTTPMethod, THandlerFunction) {}
  void onNotFound(THandlerFunction) {}
  void begin() {}
  void handleClient() {}
  void send(int c, const char*, const String& s) { g_code = c; g_resp = s.c_str(); }
  void send(int c, const char*, const char* s) { g_code = c; g_resp = s; }
  void send_P(int c, PGM_P, PGM_P s) { g_code = c; g_resp = s; }
  void sendHeader(const String&, const String&, bool = false) {}
  String arg(const String& k) { return String(g_args[k.c_str()].c_str()); }
  bool hasArg(const String& k) { return g_args.count(k.c_str()) > 0; }
  String uri() { return String(g_uri.c_str()); }
};
