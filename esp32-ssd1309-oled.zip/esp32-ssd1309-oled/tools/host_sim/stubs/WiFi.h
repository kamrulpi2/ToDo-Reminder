#pragma once
#include "Arduino.h"
enum { WIFI_OFF = 0, WIFI_STA = 1, WIFI_AP = 2, WIFI_AP_STA = 3 };
enum { WL_IDLE_STATUS = 0, WL_CONNECTED = 3, WL_DISCONNECTED = 6 };
enum { WIFI_AUTH_OPEN = 0, WIFI_AUTH_WPA2_PSK = 3 };
struct IPAddress { String toString() const { return "192.168.4.1"; } };
struct WiFiClass {
  int st = WL_DISCONNECTED;
  int status() { return st; }
  bool mode(int) { return true; }
  bool softAP(const char*) { return true; }
  IPAddress softAPIP() { return {}; }
  IPAddress localIP() { return {}; }
  bool softAPdisconnect(bool) { return true; }
  int softAPgetStationNum() { return 0; }
  int begin(const char*, const char*) { return 0; }
  bool disconnect(bool = false) { return true; }
  void setAutoReconnect(bool) {}
  void persistent(bool) {}
  void setHostname(const char*) {}
  int scanNetworks(bool, bool) { return 0; }
  String SSID() { return "home"; }
  String SSID(int) { return "net"; }
  int RSSI() { return -60; }
  int RSSI(int) { return -60; }
  int encryptionType(int) { return 3; }
  void scanDelete() {}
};
extern WiFiClass WiFi;
inline void configTzTime(const char*, const char*, const char*, const char*) {}
