// Minimal Arduino/ESP32 stand-in so the sketch can be compiled and run on a PC.
#pragma once
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdarg>
#include <cmath>
#include <ctime>
#include <string>
#include <vector>
#include <algorithm>
#include <functional>
#include <map>
#include <mutex>
#include <sys/time.h>
#include <unistd.h>
#ifndef ARDUINO
#define ARDUINO 10819
#endif
#define ESP32 1
#define PROGMEM
#define F(x) (x)
class __FlashStringHelper;
#define ARDUINOJSON_ENABLE_ARDUINO_STREAM 0
#define ARDUINOJSON_ENABLE_ARDUINO_PRINT 0

#include "Print.h"
#include "pgmspace.h"

#define DEG_TO_RAD 0.017453292519943295769236907684886
#define radians(deg) ((deg) * DEG_TO_RAD)
#define HIGH 1
#define LOW 0
#define INPUT_PULLUP 2
#define OUTPUT 1
#define constrain(amt, low, high) ((amt) < (low) ? (low) : ((amt) > (high) ? (high) : (amt)))
inline bool isDigit(int c) { return c >= '0' && c <= '9'; }

// ---- simulated clock -------------------------------------------------------
extern uint32_t g_ms;            // virtual millis()
extern long long g_base;         // epoch at g_ms == 0
inline uint32_t millis() { return g_ms; }
inline void delay(uint32_t ms) { g_ms += ms; }
inline time_t sim_time(time_t* t) { time_t v = (time_t)(g_base + g_ms / 1000); if (t) *t = v; return v; }
inline int sim_settimeofday(const struct timeval* tv, const void*) { g_base = (long long)tv->tv_sec - g_ms / 1000; return 0; }
#define time(x) sim_time(x)
#define settimeofday sim_settimeofday

inline long random(long a, long b) { return a + rand() % (b - a); }
inline void randomSeed(unsigned long s) { srand((unsigned)s); }
inline uint32_t esp_random() { return (uint32_t)rand(); }
inline void pinMode(int, int) {}
inline int digitalRead(int) { return 1; }
inline void digitalWrite(int, int) {}
inline bool ledcAttach(int, int, int) { return true; }
inline void ledcWriteTone(int, int) {}
inline void ledcSetup(int, int, int) {}
inline void ledcAttachPin(int, int) {}

#include "WString.h"

struct SerialClass {
  void begin(int) {}
  void println(const char* s) { ::printf("[serial] %s\n", s); }
  void println(const String& s) { ::printf("[serial] %s\n", s.c_str()); }
  void printf(const char* f, ...) { va_list a; va_start(a, f); ::printf("[serial] "); ::vprintf(f, a); va_end(a); }
  void print(const char* s) { ::printf("%s", s); }
};
extern SerialClass Serial;

struct EspClass {
  uint64_t getEfuseMac() { return 0xA1B2C3D4E5F6ULL; }
  uint32_t getFreeHeap() { return 200000; }
  void restart() { printf("[esp] restart\n"); }
};
extern EspClass ESP;
