#!/usr/bin/env bash
# Compiles the real BeeClock sketch on a PC (Arduino/ESP32 APIs are replaced by small stubs),
# runs logic checks (API, Firebase sync, alarms, time restore) and dumps OLED frames to frames.bin.
# Needs: g++, curl, python3 with Pillow (only for render.py).
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p libs/gfx/Fonts
R=https://raw.githubusercontent.com
for f in Adafruit_GFX.cpp Adafruit_GFX.h gfxfont.h glcdfont.c Fonts/FreeSansBold18pt7b.h; do
  [ -f libs/gfx/$f ] || curl -fsSL -o libs/gfx/$f $R/adafruit/Adafruit-GFX-Library/master/$f
done
[ -f libs/ArduinoJson.h ] || curl -fsSL -o libs/ArduinoJson.h https://github.com/bblanchon/ArduinoJson/releases/download/v7.2.1/ArduinoJson-v7.2.1.h
# the GFX library reads 32-bit pointers from flash; on a 64-bit PC read real pointers
sed -i 's|#define pgm_read_pointer(addr) ((void \*)pgm_read_dword(addr))|#define pgm_read_pointer(addr) (*(void * const *)(addr))|' libs/gfx/Adafruit_GFX.cpp
g++ -std=gnu++17 -O1 -w -I stubs -I libs/gfx -I libs -DESP32 -DARDUINO=10819 host_main.cpp libs/gfx/Adafruit_GFX.cpp -o host_sim
./host_sim frames.bin
