# Host simulation (no ESP32 needed)

`./run.sh` compiles the real `projects/bee_clock_todo` sketch on a PC against the **real** ArduinoJson 7 and Adafruit GFX
sources, with small stand-ins for the ESP32 APIs (`stubs/`). It then runs the checks in `host_main.cpp`
(web API, JSON, Firebase pull/push logic, saved time, alarm) and runs the real `displayTask` on a virtual clock,
saving OLED frames. `python3 render.py` turns them into `oled-preview.png`.

It catches type errors, logic bugs and layout problems. It does **not** test the real ESP32 WiFi/WebServer stack,
the I2C hardware or a live Firebase.
