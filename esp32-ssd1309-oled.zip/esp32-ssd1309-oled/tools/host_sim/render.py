# Turns frames.bin (written by run.sh) into oled-preview.png
import struct, sys
from PIL import Image, ImageDraw
data = open('frames.bin', 'rb').read(); n = len(data) // 8196
frames = [(struct.unpack('<I', data[i*8196:i*8196+4])[0], data[i*8196+4:(i+1)*8196]) for i in range(n)]
get = lambda t: min(frames, key=lambda f: abs(f[0] - t))
picks = [(1000, '1. splash'), (4000, '2. clock + flying bee'), (9000, '3. todo page 1'), (14000, '4. todo page 2'),
         (23500, '5. hotspot info'), (28300, '6. clock + hotspot name'), (48000, '7. WiFi connected'), (72000, '8. alarm')]
S = 3; W = 128*S; H = 64*S; pad = 22; cols = 2; rows = 4
sheet = Image.new('RGB', (cols*(W+10)+10, rows*(H+pad+10)+10), (24, 24, 28)); d = ImageDraw.Draw(sheet)
for i, (t, label) in enumerate(picks):
    ms, fb = get(t); im = Image.new('RGB', (128, 64)); px = im.load()
    for y in range(64):
        for x in range(128): px[x, y] = (190, 225, 255) if fb[y*128+x] else (0, 0, 6)
    cx = 10 + (i % cols)*(W+10); cy = 10 + (i//cols)*(H+pad+10)
    d.text((cx, cy), label, fill=(255, 255, 255)); sheet.paste(im.resize((W, H), Image.NEAREST), (cx, cy+pad))
sheet.save('oled-preview.png')
