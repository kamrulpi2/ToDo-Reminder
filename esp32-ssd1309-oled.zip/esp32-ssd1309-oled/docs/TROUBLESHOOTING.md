# Troubleshooting: ESP32 + 2.42" SSD1309 I2C OLED

Board: M242-12864-4-V2.0 (blue PCB, 4-pin header GND / VDD / SCL / SDA).
Photo of the back: [images/board-back.jpg](images/board-back.jpg)

## The problem we actually had

- Screen blank, only a flash of light at power-up.
- I2C scanner printed `Nothing found`, or only `0x1A` (not the display).
- Display code at 0x3C and 0x3D showed nothing.

## The root cause and the fix (this is what worked)

The board has two series diodes, **D1 on SCL** and **D2 on SDA**, meant for 5V-logic boards (Arduino Uno). The diode on SDA blocks the display's **ACK** reply from reaching the ESP32. The ESP32 (scanner, U8g2, Adafruit) needs that ACK, so it concluded nobody was there.

The PCB itself carries a Chinese note beside D2 which says to short D2 if the ACK response is needed.

**Fix: bridge D1 and D2.**

1. Put a little solder on each of the two pads of D2, then make one blob joining both pads (or fit a 0 ohm resistor / a short wire). Do the same for D1.
2. Check with a multimeter in continuity mode: the two pads of D2 must beep. Same for D1.
3. Do not overheat: 2-3 seconds at a time, pads lift if heated too long.
4. Do not leave solder touching neighbouring pads.
5. Unplug USB and plug it back (power cycle), then run `01_i2c_scanner`.
6. `Found device at 0x3C` means it worked.

Result on the tested unit: after bridging D1 and D2, the scanner found **0x3C** and the display worked.

## Important after bridging

- Keep **VDD at 3.3V**. With the diodes bypassed, the pull-ups (R9/R10) tie SDA and SCL to VDD, so 5V on VDD would put 5V on the ESP32 pins and can damage them.
- Do not mix this display with a 5V-logic board on the same I2C lines.

## Checklist, in order

| # | Check | How |
|---|---|---|
| 1 | Wiring | GND-GND, VDD-3V3, SCL-GPIO22, SDA-GPIO21 (the header text reads GND VDD SCL SDA) |
| 2 | Jumper wires | Use another set of wires. Bad jumpers cause hours of confusion. |
| 3 | Solder joints | Re-melt the 4 header pins if they look dull or cracked |
| 4 | Power | Multimeter between VDD and GND: about 3.3V |
| 5 | Flex cable | Fully seated in J1 with the latch closed |
| 6 | D1 / D2 | Bridge them (see above) |
| 7 | Power cycle | Unplug and replug USB. The EN button does not reset the display. |
| 8 | Scan | Upload `01_i2c_scanner`, Serial Monitor 115200 |
| 9 | Address | Use 0x3C or 0x3D, whichever the scanner shows (U8g2 wants address * 2) |
| 10 | Protective film | Peel the plastic film from the front of the panel |

## Reading the scanner result

| Scanner prints | Meaning | Do this |
|---|---|---|
| Nothing found | ESP32 cannot see the display | Bridge D1/D2, check wiring, solder, power |
| Only 0x1A | Not the display | Disconnect the display and scan again. If 0x1A stays, it is something else on the ESP32 board. Bridge D1/D2. |
| 0x3C | Display found | Use `0x3C * 2` in U8g2 |
| 0x3D | Display found | Use `0x3D * 2` in U8g2 |

## Faint light at power-up, nothing after

SSD1309 shows random pixels when powered, before it receives commands. That means the panel and boost converter are fine and the problem is communication. In our case it was the D2 diode blocking ACK.

## If the screen stays blank even though the address is found

1. Set contrast: `u8g2.setContrast(255);` after `begin()`.
2. Try another constructor:
   - `U8G2_SSD1309_128X64_NONAME0_F_HW_I2C`
   - `U8G2_SSD1309_128X64_NONAME2_F_HW_I2C`
   - `U8G2_SH1106_128X64_NONAME_F_HW_I2C`
3. Try the Adafruit SSD1306 library (`03_hello_adafruit`) with 0x3C and then 0x3D.
4. Some of these modules stay black when powered through VIN until reset. Power-cycle the USB.
5. Add 4.7k pull-ups from SDA and SCL to 3.3V (usually not needed, the board has R9/R10).
6. Lower the I2C speed: `Wire.setClock(100000);` after `Wire.begin()`.
7. Try a longer delay before `u8g2.begin()` (for example `delay(500)`).

## Other methods people use

- Use a library that does not wait for ACK (for example `OLED_I2C.h`). It works without the D2 bridge, but the bridge is the cleaner fix.
- Use SPI instead of I2C: Waveshare-style modules support it. This blue 4-pin board is I2C only, so this does not apply to it.
- Wire the RES pin to a GPIO and pulse it before `begin()`. Only possible on modules that expose a RES pin. Yours does not.

## Facts read from the board

- Driver IC: SSD1309, 128 x 64, I2C
- Address select pads: 0X7A / 0X7B (7-bit 0x3C or 0x3D)
- Pull-ups: R9, R10. Boost converter: L2 with U9.
- Printed note near D2 (Chinese): if ACK response is needed, short D2.

## Burn-in

OLED pixels age. Use `setContrast(100)` or lower for always-on screens and avoid showing a static image for days.

## BeeClock project: hotspot not visible and OLED blank

Cause found in an earlier version: the web server was started before the WiFi stack, so the ESP32 crashed at boot
and restarted forever (no hotspot, no display). Fixed. If it happens again, open Serial Monitor at 115200 and
compare with the healthy output in `projects/bee_clock_todo/README.md`.

The Adafruit SSD1306 library does not check whether the display answers, so it can draw even when the I2C scanner
cannot see the display. U8g2 and the scanner need the D1/D2 bridge. This project uses the Adafruit library.
