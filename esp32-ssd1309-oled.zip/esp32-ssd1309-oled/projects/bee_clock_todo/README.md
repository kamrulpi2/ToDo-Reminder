# BeeClock: ESP32 clock + flying bee + todo + alarms + Firebase

ESP32 DevKit V1 + 2.42" SSD1309 OLED (128x64, I2C), driven with the **Adafruit SSD1306 + GFX** libraries
(the same library as your working "Hello" sketch).

![OLED preview](../../docs/images/oled-preview.png)
*Frames from the real display code, rendered on a PC. Phone app: [docs/images/phone-app.png](../../docs/images/phone-app.png)*

**On the OLED**
- Clock scene (5 s): big time, date, a bee flying with a trail, a moon, falling stars and meteors from top to bottom
- Then the **todo list** (5 s per page, 4 tasks per page, up to 12 tasks), then back to the clock
- Alarm scene when a task is due: shaking big bee, flashing border, buzzer
- **Works with no WiFi and no internet.** The clock and the todo list are always on screen. The WiFi setup
  info only appears for a few seconds in the rotation (and in the top line of the clock).

**On your phone (web app)**
- Dark night-sky UI with a moon, falling stars, meteors and a flying bee
- Add tasks (title, date, time alarm, priority, repeat once/daily/weekly), tick, delete
- Quick time chips (+15 min, +1 hour, tonight, tomorrow), progress bar for today
- **Set time and date** (phone time in one tap, manual, internet time, time zone)
- Firebase settings, brightness, scene timing, 12/24 h, buzzer, test alarm, forget WiFi

**System**
- FreeRTOS tasks: `display`, `alarm`, `button` (core 1), `net`, `sync`, `house` (core 0)
- Fast WiFi setup with no app: hotspot + captive portal
- Tasks are saved in flash (LittleFS) and synced to Firebase Realtime Database

## Hardware

| Part | ESP32 pin |
|---|---|
| OLED SDA | GPIO 21 |
| OLED SCL | GPIO 22 |
| OLED VDD / GND | 3V3 / GND (3.3 V only) |
| Buzzer (+) | GPIO 25 (passive buzzer, other leg to GND). Optional |
| Button | BOOT button (GPIO 0), already on the DevKit |

Bridge the **D1 and D2** pads on the OLED back first (see [../../docs/TROUBLESHOOTING.md](../../docs/TROUBLESHOOTING.md)).
OLED address is `0x3C` (change `OLED_ADDR` in `config.h` if yours is `0x3D`; the code also tries the other one itself).
No buzzer: set `PIN_BUZZER` to `-1` in `config.h`.

## Install

1. Arduino IDE 2.x with the ESP32 boards package (Espressif), 2.0.x or 3.x.
2. Library Manager: **Adafruit SSD1306**, **Adafruit GFX Library**, **ArduinoJson (version 7.x)**.
   (U8g2 is *not* needed for this project.)
3. Open `bee_clock_todo.ino`. All `.h` files must stay in the same folder.
4. Board `ESP32 Dev Module`, Partition Scheme `Default 4MB with spiffs`, upload.
5. Open Serial Monitor at 115200. A healthy start prints:
   ```
   BeeClock 1.0.0 started. Hotspot name if needed: BeeClock-XXXX
   [oled] found at 0x3C
   [oled] begin: ok
   [net] start
   [net] web server started
   [net] no saved WiFi, starting hotspot
   [net] hotspot 'BeeClock-XXXX' open, setup page http://192.168.4.1
   ```

## First start: connect the phone to your WiFi (about 15 seconds)

1. Power on. The clock shows on the OLED. Within a few seconds the hotspot name `BeeClock-XXXX` appears
   (top line of the clock and on the setup screen).
2. On the phone join that WiFi (no password). The setup page opens by itself; if not, open `192.168.4.1`.
3. Tap your home WiFi, type the password, **Connect**.
4. The OLED says `ONLINE!` with the address. Join your home WiFi again on the phone and open
   `http://beeclock.local` (or the IP shown on the screen). Add it to the home screen to use it like an app.

No router? Press **Skip - use offline** on the setup page. The app then works directly on the hotspot.

## Offline behaviour (no WiFi, no internet)

- The OLED keeps showing the clock and todo list. Tasks are stored in flash.
- The ESP32 has no battery clock, so the time is saved to flash every 10 minutes and restored at power-on.
  Until internet time or your phone confirms it, the clock shows a `~` after the task count and may be a little
  behind (by the time the power was off). **Alarms stay silent while the time is only an estimate**, so a wrong
  time can never ring a wrong alarm. Fix it once: open the app -> Time & date -> *Use my phone's time now*.

## Button (BOOT)

| Action | Result |
|---|---|
| Short press | Next scene. During an alarm: snooze 5 min |
| Hold 1.5 s during an alarm | Mark the task done |
| Hold 8 s any time | Forget WiFi and restart in setup mode |

## If the hotspot does not show or the OLED stays blank

1. Open Serial Monitor (115200) and press EN. Compare with the healthy output above.
2. Repeating `Guru Meditation Error` / `rst:0xc` lines mean the chip crashes and restarts. An older version of this
   project started the web server before the WiFi stack and crashed exactly like that ("Invalid mbox"). This
   version fixes it; make sure you uploaded **this** folder, not the older zip.
3. `[oled] NOT found`: wiring, D1/D2 bridge, or power on the display (see TROUBLESHOOTING).
4. `[oled] begin: FAILED`: out of memory, restart the board.
5. Hotspot name does not appear on the phone: wait 10 s, turn phone WiFi off and on, and make sure the
   Serial line `[net] hotspot ... open` was printed.
6. Send me the Serial text and I can tell the exact cause.

## Firebase

Your database URL is already pre-filled (`config.h`, `FB_DEFAULT_URL`). See [FIREBASE.md](FIREBASE.md).
Without internet everything still works and stays on the clock.

## Files

| File | Purpose |
|---|---|
| `bee_clock_todo.ino` | setup, RTOS task creation, button |
| `config.h` | pins, limits, saved settings, default Firebase URL |
| `state.h` | shared state and mutex |
| `store.h` | task model, JSON, flash storage, saved time |
| `alarm.h` | alarm engine and buzzer |
| `ui.h` | OLED scenes and animation (Adafruit GFX) |
| `net.h` | WiFi, portal, NTP, web API |
| `firebase_sync.h` | Firebase REST sync |
| `web_pages.h` | setup page and phone app (HTML in flash) |

## What was checked, and what was not

Checked on a PC (`tools/host_sim`): the sketch compiles against the real ArduinoJson 7 and Adafruit GFX sources;
the web API handlers, JSON, Firebase pull/push logic, saved-time restore and alarm logic pass 20 checks; the real
display code was run on a virtual clock and the frames above were rendered from it; the phone pages were run in
headless Chromium against a mock API (add task, tick, alarm card, no JavaScript errors).

**Not checked** (no ESP32 or Arduino toolchain was available): compiling with the real ESP32 core, the real WiFi /
WebServer / mDNS stack, the I2C hardware, and a live Firebase. Expect that a first build may still show a small
compile error; send the exact text and it is quick to fix.

Known limits:
- Firebase uses TLS without certificate checking (`setInsecure`): fine for a todo list, not for secrets.
- Bangla or other non-ASCII task titles show on the phone, but the OLED font is ASCII only, so they appear as `?` there.
- Up to 40 tasks stored, 12 shown on the OLED.
- If power is cut before a local change is uploaded, the cloud copy wins on the next boot.
