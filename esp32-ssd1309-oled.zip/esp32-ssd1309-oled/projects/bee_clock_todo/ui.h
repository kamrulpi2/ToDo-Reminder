#pragma once
// ============================================================================
//  OLED UI (Adafruit SSD1306 + GFX, the library that works on your board)
//  Clock + flying bee + moon + falling stars, todo list, alarm, setup screens.
//  Runs in its own RTOS task and NEVER waits for WiFi or internet: the clock
//  and the todo list are always on screen.
// ============================================================================
#include <Wire.h>
#include <WiFi.h>
#include <math.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Fonts/FreeSansBold18pt7b.h>

#define SCR_W 128
#define SCR_H 64
#define C_ON  SSD1306_WHITE
#define C_OFF SSD1306_BLACK

Adafruit_SSD1306 oled(SCR_W, SCR_H, &Wire, -1);

// ---- small text helpers (built-in 5x7 font: 6 px per char at size 1) -------
String asciiOnly(const String& s) {
  String o;
  for (size_t i = 0; i < s.length(); i++) {
    unsigned char c = s[i];
    if (c < 32) continue;
    if (c > 126) { if (!o.length() || o[o.length() - 1] != '?') o += '?'; }
    else o += (char)c;
  }
  return o;
}
String clipTo(const String& s, int n) {
  if ((int)s.length() <= n) return s;
  if (n <= 1) return s.substring(0, n);
  return s.substring(0, n - 1) + ".";
}
void txt(int x, int y, const String& s, int sz = 1, uint16_t col = C_ON) {
  oled.setFont();
  oled.setTextSize(sz);
  oled.setTextColor(col);
  oled.setCursor(x, y);
  oled.print(s);
}
int txtW(const String& s, int sz = 1) { return (int)s.length() * 6 * sz; }
void txtC(int y, const String& s, int sz = 1) { txt((SCR_W - txtW(s, sz)) / 2, y, s, sz); }

void setContrastNow(uint8_t c) {
  oled.ssd1306_command(SSD1306_SETCONTRAST);
  oled.ssd1306_command(c);
}

// ---- falling stars + meteor ------------------------------------------------
#define NSTARS 24
struct Star { float x, y, v; uint8_t kind; };
Star stars[NSTARS];
struct Meteor { bool on; float x, y; uint32_t nextAt; } meteor = {false, 0, 0, 3000};

void starsInit() {
  for (auto& s : stars) {
    s.x = random(0, 128); s.y = random(0, 64);
    s.v = 5 + random(0, 160) / 10.0f;                       // 5..21 px/s (parallax)
    s.kind = random(0, 10) < 6 ? 0 : (random(0, 2) ? 1 : 2);
  }
}
void starsUpdate(float dt) {
  for (auto& s : stars) {
    s.y += s.v * dt;
    if (s.y > 66) { s.y = -2; s.x = random(0, 128); s.v = 5 + random(0, 160) / 10.0f; }
  }
  uint32_t now = millis();
  if (!meteor.on && (int32_t)(now - meteor.nextAt) > 0) { meteor.on = true; meteor.x = random(40, 140); meteor.y = -8; }
  if (meteor.on) {
    meteor.y += 75 * dt; meteor.x -= 24 * dt;               // top -> bottom, slightly diagonal
    if (meteor.y > 76) { meteor.on = false; meteor.nextAt = now + random(5000, 12000); }
  }
}
// (mx0,my0)-(mx1,my1) is a rectangle where stars are hidden (keeps the big time clean)
void starsDraw(int xmin, int xmax, bool withMeteor = true, int mx0 = 0, int my0 = 0, int mx1 = -1, int my1 = -1) {
  uint32_t ms = millis();
  for (int i = 0; i < NSTARS; i++) {
    int x = (int)stars[i].x, y = (int)stars[i].y;
    if (x < xmin || x > xmax) continue;
    if (x >= mx0 && x <= mx1 && y >= my0 && y <= my1) continue;
    bool plus = stars[i].kind == 1 || (stars[i].kind == 2 && ((ms / 280 + i) % 4 == 0));
    oled.drawPixel(x, y, C_ON);
    if (plus) { oled.drawPixel(x - 1, y, C_ON); oled.drawPixel(x + 1, y, C_ON); oled.drawPixel(x, y - 1, C_ON); oled.drawPixel(x, y + 1, C_ON); }
  }
  if (withMeteor && meteor.on) {
    int x = (int)meteor.x, y = (int)meteor.y;
    if (x >= xmin && x <= xmax) { oled.drawLine(x, y, x + 4, y - 13, C_ON); oled.drawPixel(x + 1, y, C_ON); }
  }
}

// ---- moon, wifi, bee -------------------------------------------------------
void drawMoon(int cx, int cy, int r) {
  oled.fillCircle(cx, cy, r, C_ON);
  oled.fillCircle(cx + (r * 2) / 5, cy - r / 3, (r * 9) / 10, C_OFF);
}

void drawWifi(int x, int y, int rssi, bool connected) {
  int n = !connected ? 0 : (rssi > -55 ? 4 : rssi > -65 ? 3 : rssi > -75 ? 2 : 1);
  for (int i = 0; i < 4; i++) {
    int h = 2 + i * 2;
    if (i < n) oled.fillRect(x + i * 3, y + 8 - h, 2, h, C_ON);
    else oled.drawPixel(x + i * 3, y + 7, C_ON);
  }
}

// dir = +1 faces right, -1 faces left. s = scale (1 small, 2 big)
void drawBee(int x, int y, int dir, bool flap, int s) {
  int wr = 2 * s + 1;                                              // wing (outline circle, flapping)
  if (flap) {
    oled.fillCircle(x - dir * s, y - 3 * s - wr, wr, C_OFF);
    oled.drawCircle(x - dir * s, y - 3 * s - wr, wr, C_ON);
  } else {
    oled.fillCircle(x - dir * 2 * s, y - 3 * s - s, s + 1, C_OFF);
    oled.drawCircle(x - dir * 2 * s, y - 3 * s - s, s + 1, C_ON);
  }
  oled.fillRoundRect(x - 5 * s, y - 3 * s, 10 * s, 6 * s, 3 * s, C_ON);          // body
  oled.fillRect(x - 3 * s, y - 3 * s + 1, s + 1, 6 * s - 2, C_OFF);              // stripes
  oled.fillRect(x + s, y - 3 * s + 1, s + 1, 6 * s - 2, C_OFF);
  oled.fillCircle(x + dir * 6 * s, y, 2 * s + 1, C_ON);                          // head
  oled.drawPixel(x + dir * (6 * s + (s > 1 ? 1 : 0)), y - 1, C_OFF);             // eye
  oled.drawLine(x + dir * 7 * s, y - 2 * s, x + dir * 9 * s, y - 4 * s, C_ON);   // antenna
  oled.drawLine(x - dir * 5 * s, y, x - dir * 7 * s, y + s, C_ON);               // stinger
}

// ---- scenes ----------------------------------------------------------------
void drawSplash(uint32_t el) {
  starsDraw(0, 127, false);
  txtC(10, "BeeClock", 2);
  txtC(32, "todo + alarm");
  float p = el / 2200.0f;
  int bx = -12 + (int)(p * 152);
  drawBee(bx, 52 + (int)(2.5f * sinf(p * 18)), 1, (el / 70) % 2 == 0, 1);
}

void drawClockScene(const tm& t, bool valid, int nOpen, const String& nextTxt, float ts) {
  starsDraw(0, 127, true, 0, 9, 100, 37);                         // no stars over the big digits
  drawMoon(113, 12, 8);
  if ((millis() / 500) % 2) { oled.drawPixel(100, 6, C_ON); oled.drawPixel(99, 6, C_ON); oled.drawPixel(101, 6, C_ON); oled.drawPixel(100, 5, C_ON); oled.drawPixel(100, 7, C_ON); }
  if ((millis() / 700) % 2) { oled.drawPixel(124, 36, C_ON); oled.drawPixel(123, 36, C_ON); oled.drawPixel(125, 36, C_ON); oled.drawPixel(124, 35, C_ON); oled.drawPixel(124, 37, C_ON); }

  // big time
  char hh[4], mm[4];
  int h = t.tm_hour; bool pm = false;
  if (!cfg.h24) { pm = h >= 12; h %= 12; if (h == 0) h = 12; }
  if (valid) { snprintf(hh, sizeof hh, cfg.h24 ? "%02d" : "%2d", h); snprintf(mm, sizeof mm, "%02d", t.tm_min); }
  else { strcpy(hh, "--"); strcpy(mm, "--"); }
  oled.setFont(&FreeSansBold18pt7b);
  oled.setTextSize(1);
  oled.setCursor(2, 35);
  oled.setTextColor(C_ON);
  oled.print(hh);
  bool colon = !valid || (t.tm_sec % 2) == 0;
  oled.setTextColor(colon ? C_ON : C_OFF);
  oled.print(":");
  oled.setTextColor(C_ON);
  oled.print(mm);
  oled.setFont();

  if (valid) {
    char sb[4]; snprintf(sb, sizeof sb, "%02d", t.tm_sec);
    txt(104, 27, sb);
    if (!cfg.h24) txt(104, 38, pm ? "PM" : "AM");
  }

  // top-left: wifi icon + status text (never blocks the clock)
  drawWifi(0, 0, WiFi.RSSI(), WiFi.status() == WL_CONNECTED);
  bool hotspot = (netState == NET_PORTAL || netState == NET_AP_ONLY);
  String top;
  if (hotspot && ((millis() / 2500) % 2)) top = apSsid;           // 13 chars = 78 px, fits beside the moon
  else if (netState == NET_CONNECTING) top = "connecting";
  else if (!valid) top = "set time";
  else { top = String(nOpen) + " open"; if (timeApprox) top += " ~"; }
  txt(15, 0, top);

  // bottom line: date (left), next task (right)
  if (valid) { char db[20]; strftime(db, sizeof db, "%a %d %b", &t); txt(0, 56, db); }
  else txt(0, 56, "Open phone app");
  if (nextTxt.length()) txt(SCR_W - txtW(nextTxt), 56, nextTxt);

  // flying bee with a dotted trail
  float sp = 0.6f;
  float bx = 64 + 50 * sinf(ts * sp);
  int dir = cosf(ts * sp) >= 0 ? 1 : -1;
  float by = 46 + 2.5f * sinf(ts * 2.1f);
  for (int k = 2; k <= 5; k++) {
    float tt = ts - k * 0.17f;
    oled.drawPixel((int)(64 + 50 * sinf(tt * sp)) - dir * 6, (int)(46 + 2.5f * sinf(tt * 2.1f)) + 1, C_ON);
  }
  drawBee((int)bx, (int)by, dir, (millis() / 70) % 2 == 0, 1);
}

void drawListScene(const tm& t, bool valid, const std::vector<Task>& v, int page, int pages, const String& today) {
  starsDraw(121, 127, false);
  String hm = fmtHM(t);

  txt(0, 0, "TODO");
  oled.fillCircle(37, 4, 4, C_ON);
  oled.fillCircle(39, 3, 3, C_OFF);
  if (pages > 1) { char pb[8]; snprintf(pb, sizeof pb, "%d/%d", page + 1, pages); txt(52, 0, pb); }
  if (valid) txt(SCR_W - 30, 0, hm);
  oled.drawFastHLine(0, 10, 128, C_ON);

  if (v.empty()) {
    txtC(22, "No tasks yet");
    txtC(34, "add on phone app");
    drawBee(64 + (int)(6 * sinf(millis() / 600.0f)), 52, 1, (millis() / 70) % 2 == 0, 1);
    return;
  }

  int start = page * OLED_TASKS_PER_PAGE;
  for (int i = 0; i < OLED_TASKS_PER_PAGE; i++) {
    int idx = start + i;
    if (idx >= (int)v.size()) break;
    const Task& k = v[idx];
    int y = 14 + i * 12;                                      // top of the text row
    bool done = isDone(k, today);
    bool od = valid && taskOverdue(k, t, today, hm);

    oled.drawRect(0, y - 1, 9, 9, C_ON);                      // checkbox
    if (done) { oled.drawLine(2, y + 3, 3, y + 5, C_ON); oled.drawLine(3, y + 5, 7, y, C_ON); oled.drawLine(2, y + 4, 3, y + 6, C_ON); oled.drawLine(3, y + 6, 7, y + 1, C_ON); }

    String pre = "";
    if (k.rep == 0 && k.date.length() == 10 && k.date != today) pre = k.date.substring(5);   // MM-DD
    else if (k.time.length() == 5) pre = k.time;
    int tx = 13;
    if (pre.length()) {
      if (od) { oled.fillRect(12, y - 1, 32, 9, C_ON); txt(13, y, pre, 1, C_OFF); }
      else txt(13, y, pre);
      tx = 47;
    }
    int maxc = ((k.prio == 2 ? 120 : 127) - tx) / 6;
    String title = clipTo(asciiOnly(k.title), maxc);
    txt(tx, y, title);
    if (done) oled.drawFastHLine(tx, y + 3, txtW(title), C_ON);
    if (k.prio == 2 && !done) txt(122, y, "!");
  }
}

void drawAlertScene(const String& title) {
  float ts = millis() / 1000.0f;
  bool flap = (millis() / 60) % 2 == 0;
  int jx = (int)(2 * sinf(ts * 40)), jy = (int)(2 * sinf(ts * 33));
  drawBee(30 + jx, 38 + jy, 1, flap, 2);

  if ((millis() / 300) % 2) oled.drawRect(0, 0, 128, 64, C_ON);
  txt(54, 4, "ALARM!", 2);
  String t = asciiOnly(title);
  txt(54, 24, t.substring(0, 12));
  if (t.length() > 12) txt(54, 34, clipTo(t.substring(12), 12));
  tm n; nowLocal(n);
  txt(54, 46, fmtHM(n));
  txt(4, 56, "tap=snooze hold=done");
}

// Hotspot info. Shown for a few seconds in every rotation while the hotspot is on.
void drawSetupScene(float ts, bool offlineApp) {
  starsDraw(0, 127);
  txt(0, 0, offlineApp ? "OFFLINE APP" : "WiFi SETUP", 2);
  txt(0, 19, "Join phone WiFi:");
  oled.fillRect(0, 29, 128, 11, C_ON);
  txt(2, 31, apSsid, 1, C_OFF);
  txt(0, 44, offlineApp ? "then open this page:" : "page opens by itself");
  txt(0, 55, "or go 192.168.4.1");
}

void drawIpScene(float ts) {
  starsDraw(0, 127);
  txt(0, 0, "ONLINE!", 2);
  String ip; { Guard g; ip = ipInfo; }
  txt(0, 22, "Open on your phone:");
  txt(0, 34, ip);
  txt(0, 46, "or beeclock.local");
  drawBee(112, 10 + (int)(3 * sinf(ts * 3)), -1, (millis() / 70) % 2 == 0, 1);
}

// ---- data the display needs, computed twice a second -----------------------
void buildView(std::vector<Task>& view, String& today, int& nOpen, String& nextTxt, const tm& t, bool valid) {
  std::vector<Task> v;
  { Guard g; v = tasks; }
  today = fmtDate(t);
  String hm = fmtHM(t);
  nOpen = 0; nextTxt = "";
  String best = "";
  std::vector<std::pair<String, size_t>> keys;
  for (size_t i = 0; i < v.size(); i++) {
    const Task& k = v[i];
    bool done = isDone(k, today);
    bool occ = occursToday(k, t, today);
    if (valid && !done && (occ || (k.rep == 0 && k.date.length() == 10 && k.date < today))) nOpen++;
    if (valid && !done && occ && k.time.length() == 5 && k.time > hm) { if (best.length() == 0 || k.time < best) best = k.time; }
    String dk = k.rep ? today : (k.date.length() == 10 ? k.date : String("0000-00-00"));
    String tk = k.time.length() == 5 ? k.time : String("99:99");
    keys.push_back({String(done ? "1" : "0") + dk + tk, i});
  }
  if (valid) {
    if (best.length()) nextTxt = "Next " + best;
    else if (!v.empty() && nOpen == 0) nextTxt = "All done!";
  }
  std::sort(keys.begin(), keys.end(), [](const std::pair<String, size_t>& a, const std::pair<String, size_t>& b) { return a.first < b.first; });
  view.clear();
  for (size_t i = 0; i < keys.size() && i < OLED_MAX_ROWS; i++) view.push_back(v[keys[i].second]);
}

// ---- find the OLED on the I2C bus (0x3C first, then 0x3D) -------------------
bool oledProbe(uint8_t& addr) {
  uint8_t cand[2] = {(uint8_t)OLED_ADDR, (uint8_t)(OLED_ADDR == 0x3C ? 0x3D : 0x3C)};
  for (int i = 0; i < 2; i++) {
    Wire.beginTransmission(cand[i]);
    if (Wire.endTransmission() == 0) { addr = cand[i]; return true; }
  }
  return false;
}

// ---- the display RTOS task -------------------------------------------------
void displayTask(void*) {
  Wire.begin(PIN_SDA, PIN_SCL);
  Wire.setClock(100000);
  vTaskDelay(pdMS_TO_TICKS(100));

  uint8_t addr = OLED_ADDR;
  bool present = false;
  for (int i = 0; i < 5 && !present; i++) {
    present = oledProbe(addr);
    if (!present) vTaskDelay(pdMS_TO_TICKS(200));
  }
  Serial.printf("[oled] %s at 0x%02X\n", present ? "found" : "NOT found (bridge D1/D2? wiring?) - trying anyway", addr);

  // same call as your working Hello sketch; the result is only logged, we keep running
  bool ok = oled.begin(SSD1306_SWITCHCAPVCC, addr);
  Serial.printf("[oled] begin: %s\n", ok ? "ok" : "FAILED (out of memory?)");
  Wire.setClock(400000);
  oled.setTextWrap(false);
  uint8_t curCon = cfg.contrast;
  setContrastNow(curCon);
  starsInit();

  const uint32_t t0 = millis();
  std::vector<Task> view;
  String today, nextTxt;
  int nOpen = 0;
  uint32_t lastSnap = 0, lastProbe = 0;
  int ph = 0;                       // 0 = clock, 1 = list
  uint32_t phStart = millis();
  int page = 0, lastKey = -1;
  uint32_t transStart = 0, prev = millis();
  TickType_t lastWake = xTaskGetTickCount();

  for (;;) {
    uint32_t now = millis();
    float dt = (now - prev) / 1000.0f; if (dt > 0.25f) dt = 0.25f;
    prev = now;
    if (cfg.contrast != curCon) { curCon = cfg.contrast; setContrastNow(curCon); }

    // display was unplugged / loose wire and is back: initialise it again
    if (now - lastProbe > 5000) {
      lastProbe = now;
      uint8_t a2 = addr;
      bool p = oledProbe(a2);
      if (p && !present) { addr = a2; oled.begin(SSD1306_SWITCHCAPVCC, addr); Wire.setClock(400000); setContrastNow(curCon); Serial.println("[oled] reconnected"); }
      present = p;
    }

    tm t; nowLocal(t);
    bool valid = timeValid();
    if (lastSnap == 0 || now - lastSnap > 400) { lastSnap = now; buildView(view, today, nOpen, nextTxt, t, valid); }
    starsUpdate(dt);
    float ts = now / 1000.0f;

    oled.clearDisplay();
    int key;
    if (now - t0 < 2200) { key = 1; drawSplash(now - t0); phStart = now; ph = 0; }
    else if (alertActive) { key = 2; String at; { Guard g; at = alertTitle; } drawAlertScene(at); phStart = now; ph = 0; }
    else if ((int32_t)(ipInfoUntil - now) > 0) { key = 5; drawIpScene(ts); phStart = now; ph = 0; }   // 9 s after WiFi connects
    else {
      // The clock and the todo list are ALWAYS shown, with or without WiFi / internet.
      // Rotation: clock -> todo page(s) -> [hotspot info while the hotspot is on] -> clock ...
      bool hotspot = (netState == NET_PORTAL || netState == NET_AP_ONLY);
      int pages = ((int)view.size() + OLED_TASKS_PER_PAGE - 1) / OLED_TASKS_PER_PAGE;
      if (pages < 1) pages = 1;
      uint32_t el = now - phStart;
      uint32_t lim = (ph == 0) ? cfg.clockSec * 1000UL : (ph == 1) ? cfg.listSec * 1000UL : 3500UL;
      if (sceneSkip || el >= lim) {
        sceneSkip = false; phStart = now;
        if (ph == 0) { ph = 1; page = 0; }
        else if (ph == 1) { page++; if (page >= pages) { ph = hotspot ? 2 : 0; page = 0; } }
        else ph = 0;
      }
      if (ph == 1 && page >= pages) { ph = 0; page = 0; }           // list got shorter while showing
      if (ph == 2 && !hotspot) ph = 0;                              // hotspot switched off
      if (ph == 0) { key = 10; drawClockScene(t, valid, nOpen, nextTxt, ts); }
      else if (ph == 1) { key = 20 + page; drawListScene(t, valid, view, page, pages, today); }
      else { key = 30; drawSetupScene(ts, netState == NET_AP_ONLY); }
    }
    if (key < 10) sceneSkip = false;

    // "blinds" transition whenever the scene changes
    if (key != lastKey) { lastKey = key; transStart = now; }
    if (key != 1 && now - transStart < 380) {
      float p = (now - transStart) / 380.0f;
      int h = (int)(8 * (1.0f - p));
      if (h > 0) for (int y = 0; y < 64; y += 8) oled.fillRect(0, y, 128, h, C_OFF);
    }
    oled.display();
    vTaskDelayUntil(&lastWake, pdMS_TO_TICKS(30));
  }
}
