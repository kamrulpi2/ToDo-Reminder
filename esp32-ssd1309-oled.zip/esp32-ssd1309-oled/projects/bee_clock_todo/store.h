#pragma once
// ============================================================================
//  Task model, time helpers, local (LittleFS) persistence
// ============================================================================
#include <vector>
#include <algorithm>
#include <time.h>
#include <sys/time.h>
#include <LittleFS.h>
#include <ArduinoJson.h>

struct Task {
  uint32_t id = 0;
  String   title;
  String   date;          // "YYYY-MM-DD" or ""
  String   time;          // "HH:MM" or ""
  uint8_t  prio = 1;      // 0 low, 1 normal, 2 high
  uint8_t  rep  = 0;      // 0 once, 1 daily, 2 weekly (weekday of `date`)
  bool     done = false;
  String   doneOn;        // date the task was ticked (repeating tasks reset next day)
  String   lastAlert;     // "YYYY-MM-DD HH:MM" of the last alarm (no double ring)
  uint32_t snoozeAt = 0;  // epoch, RAM only
};

std::vector<Task> tasks;
uint32_t nextId = 1;

// ---- Firebase dirty tracking (see firebase_sync.h) ----
volatile uint32_t fbGen = 1;          // bumped on every local change
volatile uint32_t fbPushedGen = 1;    // = fbGen at boot: nothing to push until the user changes something
volatile uint32_t fbDirtyAt = 0;      // millis() of the last local change
inline void markDirty() { fbGen = fbGen + 1; fbDirtyAt = millis(); }

// ---- time helpers ----------------------------------------------------------
inline bool timeValid() { return time(nullptr) > 1700000000; }
// No battery clock on the ESP32: remember the last known time in flash and restore it at boot,
// so the display shows a (slightly behind) time even with no internet. NTP/phone fixes it later.
void saveTimeNow() {
  if (!timeValid()) return;
  Guard g;
  prefs.putULong("lt", (uint32_t)time(nullptr));
}
void restoreSavedTime() {
  if (timeValid()) return;
  uint32_t lt;
  { Guard g; lt = prefs.getULong("lt", 0); }
  if (lt > 1700000000UL) {
    struct timeval tv; tv.tv_sec = (time_t)(lt + 5); tv.tv_usec = 0;
    settimeofday(&tv, nullptr);
    timeApprox = true;
  }
}
inline void nowLocal(tm& t) { time_t n = time(nullptr); localtime_r(&n, &t); }
inline String fmtDate(const tm& t) {
  char b[12]; snprintf(b, sizeof b, "%04d-%02d-%02d", t.tm_year + 1900, t.tm_mon + 1, t.tm_mday);
  return String(b);
}
inline String fmtHM(const tm& t) {
  char b[8]; snprintf(b, sizeof b, "%02d:%02d", t.tm_hour, t.tm_min);
  return String(b);
}

bool validDate(const String& s) {
  if (s.length() != 10) return false;
  for (int i = 0; i < 10; i++) {
    if (i == 4 || i == 7) { if (s[i] != '-') return false; }
    else if (!isDigit(s[i])) return false;
  }
  int m = s.substring(5, 7).toInt(), d = s.substring(8, 10).toInt();
  return m >= 1 && m <= 12 && d >= 1 && d <= 31;
}
bool validTime(const String& s) {
  if (s.length() != 5 || s[2] != ':') return false;
  if (!isDigit(s[0]) || !isDigit(s[1]) || !isDigit(s[3]) || !isDigit(s[4])) return false;
  return s.substring(0, 2).toInt() < 24 && s.substring(3, 5).toInt() < 60;
}

int weekdayOf(const String& d) {
  tm t = {};
  t.tm_year = d.substring(0, 4).toInt() - 1900;
  t.tm_mon  = d.substring(5, 7).toInt() - 1;
  t.tm_mday = d.substring(8, 10).toInt();
  t.tm_hour = 12;
  mktime(&t);
  return t.tm_wday;
}

inline bool isDone(const Task& t, const String& today) {
  return t.done && (t.rep == 0 || t.doneOn == today);
}

// Does this task belong to today?
bool occursToday(const Task& t, const tm& now, const String& today) {
  if (t.rep == 1) return true;
  if (t.rep == 2) return t.date.length() == 10 ? weekdayOf(t.date) == now.tm_wday : true;
  return t.date.length() != 10 || t.date == today;
}

bool taskOverdue(const Task& t, const tm& now, const String& today, const String& hm) {
  if (isDone(t, today)) return false;
  if (t.rep == 0 && t.date.length() == 10 && t.date < today) return true;
  return occursToday(t, now, today) && t.time.length() == 5 && t.time < hm;
}

// ---- (de)serialisation: {"t12": {...}, "t13": {...}} -----------------------
String taskKey(uint32_t id) { return String("t") + String(id); }

void tasksToJson(std::vector<Task> v, String& out) {      // by value: sorted copy
  std::sort(v.begin(), v.end(), [](const Task& a, const Task& b) { return a.id < b.id; });
  JsonDocument doc;
  JsonObject root = doc.to<JsonObject>();
  for (auto& t : v) {
    JsonObject o = root[taskKey(t.id)].to<JsonObject>();
    o["id"]    = t.id;
    o["title"] = t.title;
    o["date"]  = t.date;
    o["time"]  = t.time;
    o["prio"]  = t.prio;
    o["rep"]   = t.rep;
    o["done"]  = t.done;
    o["do"]    = t.doneOn;
    o["la"]    = t.lastAlert;
  }
  out = "";
  serializeJson(doc, out);
}

bool tasksFromJson(const String& s, std::vector<Task>& out) {
  JsonDocument doc;
  if (deserializeJson(doc, s)) return false;
  out.clear();
  if (!doc.is<JsonObject>()) return doc.isNull();
  for (JsonPair kv : doc.as<JsonObject>()) {
    JsonObject o = kv.value().as<JsonObject>();
    if (o.isNull() || out.size() >= MAX_TASKS) continue;
    Task t;
    t.id = o["id"] | 0u;
    if (!t.id) t.id = strtoul(kv.key().c_str() + 1, nullptr, 10);
    if (!t.id) continue;
    t.title     = o["title"] | "";
    t.date      = o["date"] | "";
    t.time      = o["time"] | "";
    t.prio      = o["prio"] | 1;
    t.rep       = o["rep"] | 0;
    t.done      = o["done"] | false;
    t.doneOn    = o["do"] | "";
    t.lastAlert = o["la"] | "";
    if (!validDate(t.date)) t.date = "";
    if (!validTime(t.time)) t.time = "";
    if (t.title.length() > 60) t.title = t.title.substring(0, 60);
    out.push_back(t);
  }
  return true;
}

// ---- local persistence -----------------------------------------------------
void saveTasksLocal() {
  String js;
  { Guard g; tasksToJson(tasks, js); }
  File f = LittleFS.open("/tasks.json", "w");
  if (f) { f.print(js); f.close(); }
}

void loadTasksLocal() {
  File f = LittleFS.open("/tasks.json", "r");
  if (!f) return;
  String js = f.readString();
  f.close();
  std::vector<Task> v;
  if (!tasksFromJson(js, v)) return;
  Guard g;
  tasks = v;
  nextId = 1;
  for (auto& t : tasks) if (t.id >= nextId) nextId = t.id + 1;
}

// caller must hold the Guard
Task* findTask(uint32_t id) {
  for (auto& t : tasks) if (t.id == id) return &t;
  return nullptr;
}

String cleanTitle(String s) {
  s.trim();
  String o;
  for (size_t i = 0; i < s.length(); i++) { char c = s[i]; if ((unsigned char)c >= 32 || (unsigned char)c >= 128) o += c; }
  if (o.length() > 60) {
    int n = 60;                                   // do not cut a UTF-8 character in half
    while (n > 0 && ((unsigned char)o[n] & 0xC0) == 0x80) n--;
    o = o.substring(0, n);
  }
  return o;
}
