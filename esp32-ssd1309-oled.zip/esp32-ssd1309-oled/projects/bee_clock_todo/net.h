#pragma once
// ============================================================================
//  Networking: fast WiFi setup (hotspot + captive portal), NTP, web server/API
//
//  Boot flow
//    saved WiFi?  yes -> connect (20 s)  -> ONLINE
//                 no / failed            -> hotspot "BeeClock-XXXX" (open) +
//                                           captive portal: phone pops up the
//                                           setup page, pick WiFi, done.
//    "Skip" in the portal -> offline mode: use the app straight on the hotspot.
// ============================================================================
#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <ESPmDNS.h>
#include <sys/time.h>
#include "esp_sntp.h"
#if __has_include("esp_arduino_version.h")
  #include "esp_arduino_version.h"
#endif
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  #define SNTP_IS_ON() esp_sntp_enabled()
  #define SNTP_OFF()   esp_sntp_stop()
#else
  #define SNTP_IS_ON() sntp_enabled()
  #define SNTP_OFF()   sntp_stop()
#endif
#include "web_pages.h"

WebServer server(80);
DNSServer dns;
bool portalMode = false, dnsOn = false;
bool pendingConnect = false;
String pSsid, pPass;
volatile uint8_t connState = 0;       // 0 idle, 1 connecting, 2 ok, 3 failed
uint32_t connStart = 0, apOffAt = 0;
String scanJson = "[]";

// ---- time ------------------------------------------------------------------
// Only sets the time zone. Safe to call at boot, before WiFi / TCP-IP are started.
void applyTimezone(char* out = nullptr) {
  int m;
  { Guard g; m = cfg.tzMin; }
  char tz[24];
  int a = abs(m);
  snprintf(tz, sizeof tz, "UTC%c%d:%02d", m >= 0 ? '-' : '+', a / 60, a % 60);   // POSIX sign is inverted
  setenv("TZ", tz, 1);
  tzset();
  if (out) strcpy(out, tz);
}

// Time zone + (if wanted and online) start internet time. Call only after WiFi is up.
void applyTimeConfig() {
  bool ntp;
  { Guard g; ntp = cfg.ntp; }
  char tz[24];
  applyTimezone(tz);
  if (ntp && WiFi.status() == WL_CONNECTED) {
    configTzTime(tz, "pool.ntp.org", "time.google.com", "time.cloudflare.com");
  } else if (SNTP_IS_ON()) {
    SNTP_OFF();
  }
}

// ---- helpers ---------------------------------------------------------------
void sendJson(int code, const String& s) {
  server.sendHeader("Cache-Control", "no-store");
  server.send(code, "application/json", s);
}
void sendOk() { sendJson(200, "{\"ok\":true}"); }
void sendErr(int code, const char* msg) {
  String s = "{\"ok\":false,\"err\":\""; s += msg; s += "\"}";
  sendJson(code, s);
}
bool readBody(JsonDocument& d) {
  return !deserializeJson(d, server.arg("plain"));
}

void resetWifiAndRestart() {
  { Guard g; cfg.ssid = ""; cfg.pass = ""; saveSettings(); }
  delay(200);
  ESP.restart();
}

// ---- WiFi scan for the portal ----------------------------------------------
void doScan() {
  int n = WiFi.scanNetworks(false, false);
  JsonDocument d;
  JsonArray arr = d.to<JsonArray>();
  for (int i = 0; i < n; i++) {
    String s = WiFi.SSID(i);
    if (s.length() == 0) continue;
    bool dup = false;
    for (JsonObject o : arr) if (s == o["s"].as<String>()) { dup = true; break; }
    if (dup) continue;
    JsonObject o = arr.add<JsonObject>();
    o["s"] = s;
    o["r"] = WiFi.RSSI(i);
    o["l"] = WiFi.encryptionType(i) != WIFI_AUTH_OPEN;
    if (arr.size() >= 20) break;
  }
  scanJson = "";
  serializeJson(d, scanJson);
  WiFi.scanDelete();
}

void startPortal() {
  WiFi.setAutoReconnect(false);                   // background STA scanning would kick phones off the hotspot
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAP(apSsid.c_str());                    // open hotspot = fastest for the user
  delay(150);
  dns.start(53, "*", WiFi.softAPIP());
  dnsOn = true;
  portalMode = true;
  netState = NET_PORTAL;
  doScan();
}

void onStaConnected(bool announce) {
  static bool mdnsOn = false;
  if (!mdnsOn && MDNS.begin(HOSTNAME)) { MDNS.addService("http", "tcp", 80); mdnsOn = true; }
  WiFi.setAutoReconnect(true);
  applyTimeConfig();
  if (announce) {
    { Guard g; ipInfo = WiFi.localIP().toString(); }
    ipInfoUntil = millis() + 9000;
  }
  netState = NET_ONLINE;
  if (portalMode) apOffAt = millis() + 12000;     // let the portal page show "connected" first
  fbKick = true;
}

// ---- API -------------------------------------------------------------------
void apiState() {
  JsonDocument d;
  time_t now = time(nullptr);
  tm t; localtime_r(&now, &t);
  char b[24];
  d["epoch"] = (uint32_t)now;
  d["valid"] = timeValid();
  d["tz"]    = cfg.tzMin;
  d["ntp"]   = cfg.ntp;
  strftime(b, sizeof b, "%Y-%m-%d", &t); d["date"] = String(b);
  strftime(b, sizeof b, "%H:%M:%S", &t); d["time"] = String(b);

  JsonArray arr = d["tasks"].to<JsonArray>();
  {
    Guard g;
    for (auto& k : tasks) {
      JsonObject o = arr.add<JsonObject>();
      o["id"] = k.id; o["title"] = k.title; o["date"] = k.date; o["time"] = k.time;
      o["prio"] = k.prio; o["rep"] = k.rep; o["done"] = k.done; o["do"] = k.doneOn;
      o["snz"] = k.snoozeAt > (uint32_t)now;
    }
    d["alertTitle"] = alertTitle;
  }
  d["alert"] = (bool)alertActive;

  JsonObject f = d["fb"].to<JsonObject>();
  f["on"]  = fbConfigured();
  f["ok"]  = (bool)fbOk;
  f["err"] = String(fbErr);
  f["ago"] = fbLastOk ? (int)((millis() - fbLastOk) / 1000) : -1;
  f["pend"] = (fbGen != fbPushedGen);

  d["online"] = WiFi.status() == WL_CONNECTED;
  d["ip"]     = (WiFi.status() == WL_CONNECTED) ? WiFi.localIP().toString() : WiFi.softAPIP().toString();
  d["ssid"]   = WiFi.SSID();
  d["rssi"]   = WiFi.RSSI();
  d["heap"]   = (uint32_t)ESP.getFreeHeap();
  d["up"]     = (uint32_t)(millis() / 1000);
  d["ver"]    = FW_VERSION;
  String out; serializeJson(d, out);
  sendJson(200, out);
}

void apiTaskAdd() {
  JsonDocument d;
  if (!readBody(d)) return sendErr(400, "bad json");
  String title = cleanTitle(d["title"] | "");
  String date = d["date"] | "", tm_ = d["time"] | "";
  if (title.length() == 0) return sendErr(400, "empty title");
  if (date.length() && !validDate(date)) return sendErr(400, "bad date");
  if (tm_.length() && !validTime(tm_)) return sendErr(400, "bad time");
  Guard g;
  if (tasks.size() >= MAX_TASKS) return sendErr(400, "task list full (40)");
  Task t;
  t.id = nextId++;
  t.title = title; t.date = date; t.time = tm_;
  t.prio = constrain((int)(d["prio"] | 1), 0, 2);
  t.rep  = constrain((int)(d["rep"] | 0), 0, 2);
  if (t.rep == 2 && t.date.length() != 10) { tm n; nowLocal(n); t.date = fmtDate(n); }   // weekly needs an anchor day
  tasks.push_back(t);
  saveTasksLocal(); markDirty();
  String r = "{\"ok\":true,\"id\":" + String(t.id) + "}";
  sendJson(200, r);
}

void apiTaskToggle() {
  JsonDocument d;
  if (!readBody(d)) return sendErr(400, "bad json");
  uint32_t id = d["id"] | 0u;
  tm n; nowLocal(n); String today = fmtDate(n);
  Guard g;
  Task* t = findTask(id);
  if (!t) return sendErr(404, "not found");
  if (isDone(*t, today)) { t->done = false; t->doneOn = ""; }
  else { t->done = true; t->doneOn = today; t->snoozeAt = 0; }
  if (alertActive && alertTaskId == id && t->done) alarmStop();
  saveTasksLocal(); markDirty();
  sendOk();
}

void apiTaskDelete() {
  JsonDocument d;
  if (!readBody(d)) return sendErr(400, "bad json");
  uint32_t id = d["id"] | 0u;
  Guard g;
  for (size_t i = 0; i < tasks.size(); i++) {
    if (tasks[i].id == id) {
      tasks.erase(tasks.begin() + i);
      if (alertActive && alertTaskId == id) alarmStop();
      saveTasksLocal(); markDirty();
      return sendOk();
    }
  }
  sendErr(404, "not found");
}

void apiTaskClear() {                       // remove finished one-time tasks
  tm n; nowLocal(n); String today = fmtDate(n);
  Guard g;
  tasks.erase(std::remove_if(tasks.begin(), tasks.end(), [&](const Task& t) { return t.rep == 0 && t.done; }), tasks.end());
  saveTasksLocal(); markDirty();
  sendOk();
}

void apiTime() {
  JsonDocument d;
  if (!readBody(d)) return sendErr(400, "bad json");
  {
    Guard g;
    if (d["tz"].is<int>()) cfg.tzMin = constrain((int)d["tz"], -720, 840);
    if (d["ntp"].is<bool>()) cfg.ntp = d["ntp"];
    saveSettings();
  }
  applyTimeConfig();
  double ep = d["epoch"] | 0.0;
  if (ep > 1700000000.0) {
    struct timeval tv; tv.tv_sec = (time_t)ep; tv.tv_usec = 0;
    settimeofday(&tv, nullptr);
    timeApprox = false;
    saveTimeNow();
  }
  sendOk();
}

void apiSettingsGet() {
  JsonDocument d;
  { Guard g;
    d["fbUrl"] = cfg.fbUrl; d["fbPath"] = cfg.fbPath;
    d["fbAuth"] = cfg.fbAuth.length() ? "********" : "";
    d["clockSec"] = cfg.clockSec; d["listSec"] = cfg.listSec; d["contrast"] = cfg.contrast;
    d["h24"] = cfg.h24; d["buzzer"] = cfg.buzzer; d["ntp"] = cfg.ntp; d["tz"] = cfg.tzMin;
  }
  String out; serializeJson(d, out);
  sendJson(200, out);
}

void apiSettingsPost() {
  JsonDocument d;
  if (!readBody(d)) return sendErr(400, "bad json");
  {
    Guard g;
    if (d["fbUrl"].is<const char*>())  { cfg.fbUrl = d["fbUrl"].as<String>(); cfg.fbUrl.trim(); }
    if (d["fbPath"].is<const char*>()) { cfg.fbPath = d["fbPath"].as<String>(); cfg.fbPath.trim(); }
    if (d["fbAuth"].is<const char*>()) { String a = d["fbAuth"].as<String>(); a.trim(); if (a != "********") cfg.fbAuth = a; }
    if (d["clockSec"].is<int>()) cfg.clockSec = constrain((int)d["clockSec"], 2, 60);
    if (d["listSec"].is<int>())  cfg.listSec  = constrain((int)d["listSec"], 2, 60);
    if (d["contrast"].is<int>()) cfg.contrast = constrain((int)d["contrast"], 1, 255);
    if (d["h24"].is<bool>())     cfg.h24 = d["h24"];
    if (d["buzzer"].is<bool>())  cfg.buzzer = d["buzzer"];
    saveSettings();
  }
  fbKick = true;
  sendOk();
}

void apiAlarm() {
  String uri = server.uri();
  JsonDocument d;
  readBody(d);
  if (uri.endsWith("test")) alarmTrigger(0, "Test alarm");
  else if (uri.endsWith("snooze")) alarmSnooze(constrain((int)(d["min"] | 5), 1, 120));
  else if (uri.endsWith("done")) alarmDone();
  else alarmStop();
  sendOk();
}

// ---- WiFi portal endpoints -------------------------------------------------
void portalSave() {
  JsonDocument d;
  if (!readBody(d)) return sendErr(400, "bad json");
  pSsid = d["ssid"] | "";
  pPass = d["pass"] | "";
  if (pSsid.length() == 0) return sendErr(400, "no ssid");
  pendingConnect = true;
  connState = 1;
  sendOk();
}

void portalStatus() {
  JsonDocument d;
  const char* st[] = {"idle", "connecting", "ok", "fail"};
  d["state"] = st[connState];
  d["ip"]    = WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString() : String("");
  d["host"]  = String(HOSTNAME) + ".local";
  String out; serializeJson(d, out);
  sendJson(200, out);
}

void portalOffline() {                       // keep the hotspot, use the app on it
  portalMode = false;
  if (dnsOn) { dns.stop(); dnsOn = false; }
  netState = NET_AP_ONLY;
  sendOk();
}

void handleRoot() {
  server.sendHeader("Cache-Control", "no-store");
  server.send_P(200, "text/html", portalMode ? PORTAL_HTML : APP_HTML);
}

void handleNotFound() {
  if (portalMode) {                          // captive portal: send every unknown URL to the setup page
    server.sendHeader("Location", String("http://") + WiFi.softAPIP().toString() + "/", true);
    server.send(302, "text/plain", "");
  } else server.send(404, "text/plain", "Not found");
}

void setupRoutes() {
  server.on("/", HTTP_GET, handleRoot);
  server.on("/scan", HTTP_GET, []() { if (server.hasArg("refresh")) doScan(); sendJson(200, scanJson); });
  server.on("/save", HTTP_POST, portalSave);
  server.on("/status", HTTP_GET, portalStatus);
  server.on("/offline", HTTP_POST, portalOffline);

  server.on("/api/state", HTTP_GET, apiState);
  server.on("/api/task/add", HTTP_POST, apiTaskAdd);
  server.on("/api/task/toggle", HTTP_POST, apiTaskToggle);
  server.on("/api/task/delete", HTTP_POST, apiTaskDelete);
  server.on("/api/task/clear", HTTP_POST, apiTaskClear);
  server.on("/api/time", HTTP_POST, apiTime);
  server.on("/api/settings", HTTP_GET, apiSettingsGet);
  server.on("/api/settings", HTTP_POST, apiSettingsPost);
  server.on("/api/alarm/test", HTTP_POST, apiAlarm);
  server.on("/api/alarm/snooze", HTTP_POST, apiAlarm);
  server.on("/api/alarm/done", HTTP_POST, apiAlarm);
  server.on("/api/alarm/stop", HTTP_POST, apiAlarm);
  server.on("/api/sync", HTTP_POST, []() { fbKick = true; sendOk(); });
  server.on("/api/wifi/reset", HTTP_POST, []() { sendOk(); delay(300); resetWifiAndRestart(); });
  server.onNotFound(handleNotFound);
}

// ---- the network RTOS task -------------------------------------------------
void netTask(void*) {
  Serial.println("[net] start");
  // IMPORTANT: the WiFi/TCP-IP stack must be started BEFORE server.begin(),
  // otherwise the ESP32 crashes at boot ("Invalid mbox") and reboots forever.
  WiFi.persistent(false);                    // credentials live in our own NVS store
  WiFi.setHostname(HOSTNAME);
  WiFi.mode(WIFI_STA);
  vTaskDelay(pdMS_TO_TICKS(300));
  setupRoutes();
  server.begin();
  Serial.println("[net] web server started");

  String ssid, pass;
  { Guard g; ssid = cfg.ssid; pass = cfg.pass; }
  bool wasConn = false;

  uint32_t lastRetry = millis();
  if (ssid.length()) {
    netState = NET_CONNECTING;
    Serial.printf("[net] connecting to saved WiFi '%s'\n", ssid.c_str());
    WiFi.setAutoReconnect(true);
    WiFi.begin(ssid.c_str(), pass.c_str());
    uint32_t t0 = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - t0 < 20000) vTaskDelay(pdMS_TO_TICKS(100));
    if (WiFi.status() == WL_CONNECTED) { wasConn = true; onStaConnected(true); Serial.printf("[net] online, IP %s\n", WiFi.localIP().toString().c_str()); }
    else { Serial.println("[net] saved WiFi failed, starting hotspot"); startPortal(); }
  } else {
    Serial.println("[net] no saved WiFi, starting hotspot");
    startPortal();
  }
  if (portalMode) Serial.printf("[net] hotspot '%s' open, setup page http://192.168.4.1\n", apSsid.c_str());

  uint32_t lastMon = 0;
  for (;;) {
    server.handleClient();
    if (dnsOn) dns.processNextRequest();

    if (pendingConnect) {                    // user pressed "Connect" in the portal
      pendingConnect = false;
      connStart = millis();
      WiFi.disconnect(false);
      WiFi.begin(pSsid.c_str(), pPass.c_str());
    }
    if (connState == 1) {
      if (WiFi.status() == WL_CONNECTED) {
        connState = 2;
        { Guard g; cfg.ssid = pSsid; cfg.pass = pPass; saveSettings(); }
        wasConn = true;
        onStaConnected(true);
      } else if (millis() - connStart > 20000) {
        connState = 3;                       // wrong password / out of range
      }
    }
    if (apOffAt && (int32_t)(millis() - apOffAt) > 0) {
      apOffAt = 0;
      if (dnsOn) { dns.stop(); dnsOn = false; }
      WiFi.softAPdisconnect(true);
      WiFi.mode(WIFI_STA);
      portalMode = false;
    }

    uint32_t now = millis();
    if (now - lastMon > 1000) {
      lastMon = now;
      bool c = WiFi.status() == WL_CONNECTED;
      if (c && !wasConn) { wasConn = true; onStaConnected(false); }   // reconnected later: re-sync time
      if (!c) wasConn = false;
      // router was off at boot (power cut): keep trying the saved WiFi while the portal is open,
      // but only when nobody is using the hotspot, so a phone is never kicked off mid-setup
      if (!c && portalMode && connState != 1 && now - lastRetry > 60000 && WiFi.softAPgetStationNum() == 0) {
        String s2, p2;
        { Guard g; s2 = cfg.ssid; p2 = cfg.pass; }
        lastRetry = now;
        if (s2.length()) WiFi.begin(s2.c_str(), p2.c_str());
      }
    }
    vTaskDelay(pdMS_TO_TICKS(2));
  }
}

// ---- housekeeping: remember the time in flash, notice when NTP corrected it ----
void housekeepingTask(void*) {
  uint32_t lastSave = millis();
  bool wasValid = timeValid();
  for (;;) {
    vTaskDelay(pdMS_TO_TICKS(1000));
    bool v = timeValid();
    // internet time arrived (only matters while the time is still an estimate)
    if (timeApprox && sntp_get_sync_status() == SNTP_SYNC_STATUS_COMPLETED) {
      timeApprox = false;
      v = true; wasValid = false;                                  // force one save below
    }
    if (v && !wasValid) { saveTimeNow(); lastSave = millis(); }    // first valid time after boot
    wasValid = v;
    if (millis() - lastSave > 600000UL) { lastSave = millis(); saveTimeNow(); }   // every 10 min
  }
}
