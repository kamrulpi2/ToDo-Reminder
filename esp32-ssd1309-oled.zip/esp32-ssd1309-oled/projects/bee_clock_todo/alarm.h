#pragma once
// ============================================================================
//  Alarm / reminder engine + buzzer
//  - a task rings at its HH:MM (once, daily or weekly)
//  - button: short press = snooze 5 min, hold 1.5 s = mark done
//  - web app: Snooze / Done / Stop
// ============================================================================
#if __has_include("esp_arduino_version.h")
  #include "esp_arduino_version.h"
#endif

#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  #define BUZZ_V3 1
#else
  #define BUZZ_V3 0
#endif

void buzzerInit() {
  pinMode(PIN_LED, OUTPUT);
  if (PIN_BUZZER < 0) return;
#if BUZZ_V3
  ledcAttach(PIN_BUZZER, 2000, 8);
#else
  ledcSetup(0, 2000, 8);
  ledcAttachPin(PIN_BUZZER, 0);
#endif
}

void buzz(int freq) {
  if (PIN_BUZZER < 0) return;
#if BUZZ_V3
  ledcWriteTone(PIN_BUZZER, freq);
#else
  ledcWriteTone(0, freq);
#endif
}

void alarmStop() {
  alertActive = false;
  buzz(0);
  digitalWrite(PIN_LED, LOW);
}

void alarmTrigger(uint32_t taskId, const String& title) {
  { Guard g; alertTitle = title; }
  alertTaskId = taskId;
  alertStartMs = millis();
  alertActive = true;
}

void alarmSnooze(int minutes) {
  { Guard g; Task* t = findTask(alertTaskId); if (t) t->snoozeAt = (uint32_t)time(nullptr) + minutes * 60; }
  alarmStop();
}

void alarmDone() {
  {
    Guard g;
    Task* t = findTask(alertTaskId);
    if (t) {
      tm now; nowLocal(now);
      t->done = true; t->doneOn = fmtDate(now); t->snoozeAt = 0;
      saveTasksLocal(); markDirty();
    }
  }
  alarmStop();
}

// look for a task that must ring right now
void checkDue() {
  if (alertActive) return;
  tm now; nowLocal(now);
  String today = fmtDate(now), hm = fmtHM(now);
  uint32_t ne = (uint32_t)time(nullptr);
  Guard g;
  for (auto& t : tasks) {
    if (isDone(t, today) || t.time.length() != 5) continue;
    if (t.snoozeAt) {                                   // snoozed: ring when time is up
      if (ne >= t.snoozeAt) { t.snoozeAt = 0; alarmTrigger(t.id, t.title); return; }
      continue;
    }
    if (!occursToday(t, now, today) || t.time != hm) continue;
    String key = today + " " + t.time;
    if (t.lastAlert == key) continue;                   // already rang this minute
    t.lastAlert = key;
    saveTasksLocal(); markDirty();
    alarmTrigger(t.id, t.title);
    return;
  }
}

void alarmTask(void*) {
  uint32_t lastCheck = 0;
  bool lastOn = false;
  for (;;) {
    vTaskDelay(pdMS_TO_TICKS(50));
    uint32_t now = millis();
    if (timeValid() && !timeApprox && now - lastCheck >= 500) { lastCheck = now; checkDue(); }

    if (alertActive) {
      uint32_t el = now - alertStartMs;
      if (el > 60000UL) { alarmStop(); lastOn = false; continue; }   // auto stop after 1 min
      uint32_t ph = el % 1600;                                       // beep-beep-beep ... pause
      bool on = (ph < 100) || (ph >= 200 && ph < 300) || (ph >= 400 && ph < 500);
      if (on != lastOn) {
        lastOn = on;
        buzz((on && cfg.buzzer) ? 2700 : 0);
        digitalWrite(PIN_LED, on ? HIGH : LOW);
      }
    } else if (lastOn) {
      lastOn = false; buzz(0); digitalWrite(PIN_LED, LOW);
    }
  }
}
