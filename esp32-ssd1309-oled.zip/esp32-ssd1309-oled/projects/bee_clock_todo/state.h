#pragma once
// ============================================================================
//  Shared state between the RTOS tasks
// ============================================================================
#include <Arduino.h>
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>

enum NetState : uint8_t {
  NET_BOOT,        // starting
  NET_CONNECTING,  // joining saved WiFi
  NET_PORTAL,      // setup hotspot + captive portal
  NET_ONLINE,      // connected to home WiFi
  NET_AP_ONLY      // user chose offline mode (phone talks to the hotspot)
};

volatile NetState netState = NET_BOOT;
String   apSsid;                       // hotspot name, set once in setup()
String   ipInfo;                       // guarded by Guard
volatile uint32_t ipInfoUntil = 0;     // show "online" screen until this millis()

// ---- alarm state ----
volatile bool     alertActive  = false;
volatile uint32_t alertStartMs = 0;
volatile uint32_t alertTaskId  = 0;
String            alertTitle;          // guarded by Guard

volatile bool sceneSkip = false;       // button: jump to next scene
volatile bool timeApprox = false;      // time restored from flash (no internet yet), may be a little behind

// ---- one recursive mutex protects tasks[], cfg strings and the strings above
SemaphoreHandle_t gMutex;

struct Guard {
  Guard()  { xSemaphoreTakeRecursive(gMutex, portMAX_DELAY); }
  ~Guard() { xSemaphoreGiveRecursive(gMutex); }
};
