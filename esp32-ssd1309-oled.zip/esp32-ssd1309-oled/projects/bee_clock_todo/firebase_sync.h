#pragma once
// ============================================================================
//  Firebase Realtime Database sync (REST, no SDK)
//    GET/PUT  https://<db>/<path>/tasks.json[?auth=<secret>]
//  - local change  -> pushed after 1.5 s (changes are batched)
//  - every 20 s    -> pull, so edits made in the Firebase console appear here
//  - if the cloud is empty the first time, local tasks are uploaded (seed)
// ============================================================================
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>

volatile bool fbOk = false;
volatile bool fbKick = false;          // settings changed -> re-sync now
volatile uint32_t fbLastOk = 0;        // millis() of last success
char fbErr[48] = "";
bool fbSeeded = false;                 // have we ever talked to the cloud?

bool fbConfigured() {
  Guard g;
  String u = cfg.fbUrl; u.trim();
  return u.startsWith("https://");
}

bool fbBuildUrl(const char* node, String& url) {
  String base, path, auth;
  { Guard g; base = cfg.fbUrl; path = cfg.fbPath; auth = cfg.fbAuth; }
  base.trim(); path.trim(); auth.trim();
  while (base.endsWith("/")) base.remove(base.length() - 1);
  while (path.startsWith("/")) path.remove(0, 1);
  while (path.endsWith("/")) path.remove(path.length() - 1);
  if (!base.startsWith("https://")) return false;
  if (path.length() == 0) path = defaultFbPath();
  url = base + "/" + path + "/" + node + ".json";
  if (auth.length()) url += "?auth=" + auth;
  return true;
}

int fbRequest(bool put, const String& url, const String& body, String& resp) {
  WiFiClientSecure client;
  client.setInsecure();                // no certificate pinning (see README)
  HTTPClient http;
  http.setConnectTimeout(7000);
  http.setTimeout(9000);
  if (!http.begin(client, url)) return -1;
  int code;
  if (put) { http.addHeader("Content-Type", "application/json"); code = http.PUT(body); }
  else code = http.GET();
  if (code > 0) resp = http.getString();
  http.end();
  return code;
}

void fbSetErr(const char* what, int code) {
  fbOk = false;
  if (code < 0) snprintf(fbErr, sizeof fbErr, "%s: no connection", what);
  else if (code == 401 || code == 403) snprintf(fbErr, sizeof fbErr, "%s: denied (%d) check rules/auth", what, code);
  else if (code == 404) snprintf(fbErr, sizeof fbErr, "%s: wrong database URL (404)", what);
  else snprintf(fbErr, sizeof fbErr, "%s: HTTP %d", what, code);
}

bool fbPush() {
  String url, body, resp;
  if (!fbBuildUrl("tasks", url)) return false;
  uint32_t gen;
  { Guard g; gen = fbGen; tasksToJson(tasks, body); }
  int code = fbRequest(true, url, body, resp);
  if (code == 200) {
    fbOk = true; fbErr[0] = 0; fbLastOk = millis(); fbPushedGen = gen; fbSeeded = true;
    return true;
  }
  fbSetErr("push", code);
  return false;
}

bool fbPull() {
  String url, body;
  if (!fbBuildUrl("tasks", url)) return false;
  uint32_t gen = fbGen;
  int code = fbRequest(false, url, "", body);
  if (code != 200) { fbSetErr("pull", code); return false; }
  fbOk = true; fbErr[0] = 0; fbLastOk = millis();
  body.trim();

  std::vector<Task> remote;
  bool isNull = (body.length() == 0 || body == "null");
  if (!isNull && !tasksFromJson(body, remote)) { snprintf(fbErr, sizeof fbErr, "pull: bad data"); fbOk = false; return false; }

  Guard g;
  if (fbGen != gen || fbGen != fbPushedGen) return true;       // local changes pending: they win

  if (isNull) {
    if (!fbSeeded) { fbSeeded = true; if (!tasks.empty()) markDirty(); }   // first run: upload ours
    else if (!tasks.empty()) { tasks.clear(); saveTasksLocal(); }          // cloud was emptied
    return true;
  }
  fbSeeded = true;

  String rs, ls;
  tasksToJson(remote, rs);
  tasksToJson(tasks, ls);
  if (rs != ls) {
    for (auto& r : remote) { Task* l = findTask(r.id); if (l) r.snoozeAt = l->snoozeAt; }
    tasks = remote;
    nextId = 1;
    for (auto& t : tasks) if (t.id >= nextId) nextId = t.id + 1;
    saveTasksLocal();
  }
  return true;
}

void syncTask(void*) {
  uint32_t lastPull = 0, retryAt = 0;
  for (;;) {
    vTaskDelay(pdMS_TO_TICKS(500));
    if (WiFi.status() != WL_CONNECTED || !fbConfigured()) { fbOk = false; continue; }
    uint32_t now = millis();
    if (fbKick) { fbKick = false; lastPull = 0; retryAt = 0; fbSeeded = false; }
    bool dirty = (fbGen != fbPushedGen);
    if (dirty) {
      if (now - fbDirtyAt > 1500 && (int32_t)(now - retryAt) >= 0) {
        if (!fbPush()) retryAt = now + 10000;
      }
    } else if (lastPull == 0 || now - lastPull > 20000) {
      lastPull = now;
      fbPull();
    }
  }
}
