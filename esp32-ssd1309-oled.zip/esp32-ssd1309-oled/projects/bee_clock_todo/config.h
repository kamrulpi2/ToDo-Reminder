#pragma once
// ============================================================================
//  BeeClock - settings and hardware pins
// ============================================================================
#include <Arduino.h>
#include <Preferences.h>

#define FW_VERSION "1.0.0"
#define HOSTNAME   "beeclock"          // http://beeclock.local
#define FB_DEFAULT_URL "https://test1-99d84-default-rtdb.asia-southeast1.firebasedatabase.app"

// ---- Hardware pins (change here if you wire differently) -------------------
#define PIN_SDA     21
#define PIN_SCL     22
#define OLED_ADDR   0x3C               // 7-bit I2C address (0x3C or 0x3D)
#define PIN_BUZZER  25                 // passive buzzer (+). Set to -1 to disable
#define PIN_LED     2                  // on-board LED, blinks during alarm
#define PIN_BTN     0                  // BOOT button

// ---- Limits ----------------------------------------------------------------
#define MAX_TASKS            40
#define OLED_TASKS_PER_PAGE  4
#define OLED_MAX_ROWS        12        // tasks shown on the OLED (3 pages)

// ---- Persistent settings (stored in NVS, edited from the web app) ----------
struct Settings {
  String  ssid, pass;                  // home WiFi
  int     tzMin    = 360;              // minutes east of UTC (Dhaka = +360)
  bool    ntp      = true;             // auto time from internet
  bool    h24      = true;             // 24 hour clock
  bool    buzzer   = true;
  uint8_t contrast = 180;              // OLED brightness 1..255
  uint8_t clockSec = 5;                // seconds on clock scene
  uint8_t listSec  = 5;                // seconds per todo page
  String  fbUrl, fbAuth, fbPath;       // Firebase Realtime Database
};

Settings cfg;
Preferences prefs;

inline String defaultFbPath() {
  char b[28];
  snprintf(b, sizeof b, "beeclock-%08x", (unsigned)(uint32_t)ESP.getEfuseMac());
  return String(b);
}

void loadSettings() {
  prefs.begin("beeclock", false);
  cfg.ssid     = prefs.getString("ssid", "");
  cfg.pass     = prefs.getString("pass", "");
  cfg.tzMin    = prefs.getInt("tz", 360);
  cfg.ntp      = prefs.getBool("ntp", true);
  cfg.h24      = prefs.getBool("h24", true);
  cfg.buzzer   = prefs.getBool("buz", true);
  cfg.contrast = prefs.getUChar("con", 180);
  cfg.clockSec = prefs.getUChar("cks", 5);
  cfg.listSec  = prefs.getUChar("lss", 5);
  cfg.fbUrl    = prefs.getString("fburl", FB_DEFAULT_URL);
  cfg.fbAuth   = prefs.getString("fbauth", "");
  cfg.fbPath   = prefs.getString("fbpath", defaultFbPath());
}

void saveSettings() {
  prefs.putString("ssid", cfg.ssid);
  prefs.putString("pass", cfg.pass);
  prefs.putInt("tz", cfg.tzMin);
  prefs.putBool("ntp", cfg.ntp);
  prefs.putBool("h24", cfg.h24);
  prefs.putBool("buz", cfg.buzzer);
  prefs.putUChar("con", cfg.contrast);
  prefs.putUChar("cks", cfg.clockSec);
  prefs.putUChar("lss", cfg.listSec);
  prefs.putString("fburl", cfg.fbUrl);
  prefs.putString("fbauth", cfg.fbAuth);
  prefs.putString("fbpath", cfg.fbPath);
}
