# Firebase Realtime Database setup (5 minutes, free Spark plan)

**Your database is already pre-filled in the firmware** (`FB_DEFAULT_URL` in `config.h`):
`https://test1-99d84-default-rtdb.asia-southeast1.firebasedatabase.app`.
Only this `databaseURL` is used. The other values of the Firebase web config (apiKey, appId, ...) are for web
apps and are not needed. With your current rules (`".read": true, ".write": true`) it works at once, but **anyone
who finds the URL can read, change or delete the whole database**. Switch to the path-limited rules in step 4
when you can (set the same path name in the app).

1. Go to https://console.firebase.google.com and create a project (turn Google Analytics off).
2. **Build -> Realtime Database -> Create Database**. Pick a region and **Locked mode**.
3. Copy the database URL shown at the top, like `https://myproject-default-rtdb.firebasedatabase.app`.
4. Open the **Rules** tab and replace the rules with the following. Change `my-secret-todo-1234` to your own long random word:

```json
{
  "rules": {
    ".read": false,
    ".write": false,
    "my-secret-todo-1234": {
      ".read": true,
      ".write": true
    }
  }
}
```

   Only someone who knows that exact path can read or write. Nobody can list the database root.
5. In the phone app: **Cloud & display settings**
   - Firebase URL: paste the URL from step 3
   - Data path: `my-secret-todo-1234` (same as in the rules)
   - Auth secret: leave empty
   - **Save settings**
6. The top pill changes to **Cloud synced**.

Your tasks are stored at `<URL>/<path>/tasks`. You can edit them in the Firebase console and the clock picks the change up within 20 seconds.

## How sync works

- A change on the phone or the clock is saved locally at once and uploaded after about 1.5 s.
- Every 20 s the clock downloads the cloud copy. If there are no unsent local changes, the cloud copy wins.
- First time, if the cloud is empty, the clock uploads what it has.
- Cloud errors appear in the settings section: `denied (401/403)` means the rules or path do not match, `wrong database URL (404)` means a wrong URL.

## Stronger security (optional)

The path name acts like a password, which is enough for a todo list. For more protection use the database secret (Project settings -> Service accounts -> Database secrets) in the "Auth secret" box and set the rules to `".read": "auth != null"`. Legacy database secrets are deprecated by Google, so check that your project still offers them.
