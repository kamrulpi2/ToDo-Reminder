// ============================================================================
//  BeeClock - ESP32 + 2.42" SSD1309 OLED
//  Clock with a flying bee, moon and falling stars. After 5 s the todo list
//  shows. Phone web app (WiFi setup portal, tasks, time/date, alarms) and
//  Firebase Realtime Database sync. Everything runs as FreeRTOS tasks.
//
//  Libraries (Library Manager): Adafruit SSD1306, Adafruit GFX Library, ArduinoJson (v7)
//  Board: "ESP32 Dev Module"   Partition: Default 4MB with spiffs
//  Display: SDA=21 SCL=22 (D1/D2 pads bridged, see docs/TROUBLESHOOTING.md)
// ============================================================================
#include <Arduino.h>
#include <LittleFS.h>
#include "config.h"
#include "state.h"
#include "store.h"
#include "firebase_sync.h"
#include "alarm.h"
#include "ui.h"
#include "net.h"

// BOOT button: short press = next scene / snooze, hold 1.5 s = done, hold 8 s = reset WiFi
void buttonTask(void*) {
  pinMode(PIN_BTN, INPUT_PULLUP);
  bool down = false, longDone = false, resetDone = false;
  uint32_t t0 = 0;
  for (;;) {
    vTaskDelay(pdMS_TO_TICKS(25));
    bool p = digitalRead(PIN_BTN) == LOW;
    uint32_t now = millis();
    if (p && !down) { down = true; longDone = false; resetDone = false; t0 = now; }
    if (p && down) {
      uint32_t held = now - t0;
      if (!longDone && held > 1500 && alertActive) { longDone = true; alarmDone(); }
      if (!resetDone && held > 8000) { resetDone = true; resetWifiAndRestart(); }
    }
    if (!p && down) {
      down = false;
      uint32_t held = now - t0;
      if (held > 40 && held < 1500 && !longDone) {
        if (alertActive) alarmSnooze(5);
        else sceneSkip = true;
      }
    }
  }
}

void setup() {
  Serial.begin(115200);
  gMutex = xSemaphoreCreateRecursiveMutex();

  if (!LittleFS.begin(true)) Serial.println("LittleFS mount failed");
  loadSettings();
  loadTasksLocal();

  // hotspot name from the chip's own MAC (reading it does not need WiFi to be started)
  uint64_t efuse = ESP.getEfuseMac();
  char b[24];
  snprintf(b, sizeof b, "BeeClock-%02X%02X", (unsigned)((efuse >> 32) & 0xFF), (unsigned)((efuse >> 40) & 0xFF));
  apSsid = b;

  applyTimezone();                   // time zone only: WiFi / TCP-IP are not started yet
  restoreSavedTime();                // no battery clock: start from the last time saved in flash
  buzzerInit();
  randomSeed(esp_random());

  // core 1: display + alarm + button (smooth animation)   core 0: network + cloud
  xTaskCreatePinnedToCore(displayTask, "display", 8192, nullptr, 3, nullptr, 1);
  xTaskCreatePinnedToCore(alarmTask,   "alarm",   4096, nullptr, 2, nullptr, 1);
  xTaskCreatePinnedToCore(buttonTask,  "button",  3072, nullptr, 2, nullptr, 1);
  xTaskCreatePinnedToCore(netTask,     "net",    10240, nullptr, 2, nullptr, 0);
  xTaskCreatePinnedToCore(syncTask,    "sync",   16384, nullptr, 1, nullptr, 0);
  xTaskCreatePinnedToCore(housekeepingTask, "house", 3072, nullptr, 1, nullptr, 0);

  Serial.printf("BeeClock %s started. Hotspot name if needed: %s\n", FW_VERSION, apSsid.c_str());
}

void loop() {
  vTaskDelay(pdMS_TO_TICKS(1000));   // all work happens in the RTOS tasks
}
